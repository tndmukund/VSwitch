#!/usr/bin/env python3
"""OT Virtual Switch - LICENCE GENERATOR (vendor tool - do NOT give this or your private key to customers).

  python otsw_licensor.py              opens the window
  python otsw_licensor.py genkey       make your vendor key pair (once) and put the public key into app/license.py
  python otsw_licensor.py sign --customer "ACME" --edition otfw [--modules l2,l3] [--expires 2027-12-31] [--hw MACHINEID]
"""
import argparse, os, re, secrets, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (os.path.join(HERE, "..", "app"), HERE, getattr(sys, "_MEIPASS", HERE)):
    sys.path.insert(0, p)
import license as L

KEYFILE = os.path.join(HERE, "vendor-private.key")


def load_seed(path):
    return bytes.fromhex(open(path).read().strip())


def genkey(path=KEYFILE):
    if os.path.exists(path): raise SystemExit(f"{path} already exists - refusing to overwrite your key. Delete it yourself if you really want a new one.")
    seed = secrets.token_bytes(32)
    open(path, "w").write(seed.hex() + "\n")
    try: os.chmod(path, 0o600)
    except OSError: pass
    pub = L.public_key(seed).hex()
    lp = os.path.join(HERE, "..", "app", "license.py")
    note = ""
    if os.path.exists(lp):
        t = open(lp).read()
        t2 = re.sub(r'PUBKEY = "[0-9a-f]{64}"', f'PUBKEY = "{pub}"', t)
        open(lp, "w").write(t2); note = f"\napp/license.py updated. Rebuild the images so they contain the new public key."
    return pub, note


def issue(seed, customer, edition, modules, expires, hw):
    mods = [m for m in modules if m in L.KEYS]
    if not mods: raise ValueError("choose at least one module")
    pl = {"id": "OT-" + time.strftime("%Y%m%d") + "-" + secrets.token_hex(3).upper(), "customer": customer, "edition": edition,
          "modules": L.close(mods, set(L.KEYS)), "issued": time.strftime("%Y-%m-%d"), "expires": expires or None, "hw": (hw or "").strip().upper() or None}
    return L.make_token(seed, pl), pl


def cli():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("genkey")
    s = sub.add_parser("sign")
    s.add_argument("--key", default=KEYFILE); s.add_argument("--customer", required=True)
    s.add_argument("--edition", default="custom"); s.add_argument("--modules", default="")
    s.add_argument("--expires", default=""); s.add_argument("--hw", default="")
    a = ap.parse_args()
    if a.cmd == "genkey":
        pub, note = genkey(); print("Private key written to", KEYFILE, "- KEEP IT SECRET AND BACK IT UP.\nPublic key:", pub + note); return
    ed = {k: m for k, n, m, d in L.EDITIONS}
    mods = a.modules.split(",") if a.modules else ed.get(a.edition, [])
    tok, pl = issue(load_seed(a.key), a.customer, a.edition, mods, a.expires, a.hw)
    fn = re.sub(r"[^\w.-]", "_", a.customer) + ".lic"
    open(fn, "w").write(tok + "\n"); print(tok); print("saved", fn, pl)


def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    r = tk.Tk(); r.title("OT Switch - Licence Generator (vendor only)"); r.geometry("720x640")
    f = ttk.Frame(r, padding=12); f.pack(fill="both", expand=True)
    key = tk.StringVar(value=KEYFILE if os.path.exists(KEYFILE) else "")
    cust, exp, hw, edn = tk.StringVar(), tk.StringVar(), tk.StringVar(), tk.StringVar(value="Everything")
    ttk.Label(f, text="1. Your private key file", font=("Segoe UI", 10, "bold")).pack(anchor="w")
    row = ttk.Frame(f); row.pack(fill="x"); ttk.Entry(row, textvariable=key).pack(side="left", fill="x", expand=True)
    def browse():
        p = filedialog.askopenfilename()
        if p: key.set(p)
    def mk():
        try:
            pub, note = genkey(); key.set(KEYFILE); messagebox.showinfo("Key created", f"Saved {KEYFILE}\nBack it up and keep it secret.\n\nPublic key:\n{pub}{note}")
        except SystemExit as e: messagebox.showerror("Key", str(e))
    ttk.Button(row, text="Browse", command=browse).pack(side="left", padx=4); ttk.Button(row, text="Create new key pair", command=mk).pack(side="left")
    ttk.Label(f, text="2. Customer", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 0)); ttk.Entry(f, textvariable=cust).pack(fill="x")
    ttk.Label(f, text="3. Edition (fills the module boxes - you can still change them)", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 0))
    cb = ttk.Combobox(f, textvariable=edn, values=[n for k, n, m, d in L.EDITIONS], state="readonly"); cb.pack(fill="x")
    vars_ = {k: tk.BooleanVar(value=True) for k in L.KEYS}
    mf = ttk.Frame(f); mf.pack(fill="x", pady=4)
    for k, n, d in L.MODULES: ttk.Checkbutton(mf, text=f"{n} - {d}", variable=vars_[k]).pack(anchor="w")
    def pick(_=None):
        e = next(x for x in L.EDITIONS if x[1] == edn.get())
        for k in L.KEYS: vars_[k].set(k in e[2])
    cb.bind("<<ComboboxSelected>>", pick)
    ttk.Label(f, text="4. Valid until (YYYY-MM-DD, empty = never)", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(8, 0)); ttk.Entry(f, textvariable=exp).pack(fill="x")
    ttk.Label(f, text="5. Lock to one appliance: customer's Machine ID (empty = any appliance)", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(8, 0)); ttk.Entry(f, textvariable=hw).pack(fill="x")
    out = tk.Text(f, height=7, wrap="char"); 
    def gen():
        try:
            tok, pl = issue(load_seed(key.get()), cust.get().strip() or "Customer", edn.get(), [k for k in L.KEYS if vars_[k].get()], exp.get().strip(), hw.get())
        except Exception as e: return messagebox.showerror("Cannot create licence", str(e))
        out.delete("1.0", "end"); out.insert("1.0", tok); r.clipboard_clear(); r.clipboard_append(tok)
        p = filedialog.asksaveasfilename(defaultextension=".lic", initialfile=re.sub(r"[^\w.-]", "_", cust.get() or "licence") + ".lic")
        if p: open(p, "w").write(tok + "\n")
        messagebox.showinfo("Done", f"Licence {pl['id']} created and copied to the clipboard.\nSend the text (or the .lic file) to the customer.")
    ttk.Button(f, text="Create licence key", command=gen).pack(pady=8); out.pack(fill="both", expand=True)
    r.mainloop()


if __name__ == "__main__":
    cli() if len(sys.argv) > 1 else gui()
