#!/usr/bin/env python3
"""OT Switch Tool - small GUI for Windows / Linux.
  * Find the OT Virtual Switch on your network and open its web GUI
  * Try the switch in DEMO (simulation) mode on this computer - nothing on your network is changed
Built into a single .exe / binary by the GitHub workflow."""
import concurrent.futures, ipaddress, json, os, socket, sys, threading, urllib.request, webbrowser
import tkinter as tk
from tkinter import messagebox, ttk

APPDATA = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~/.local/share"), "OT-Switch-Tool")
os.makedirs(APPDATA, exist_ok=True)
os.environ.setdefault("OTSW_DATA", APPDATA)          # demo config survives restarts
os.environ["OTSW_SIM"] = "1"                        # the launcher only ever runs the harmless demo
sys.path.insert(0, getattr(sys, "_MEIPASS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app")))
PORTS = (80, 8080)


def local_subnets():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1)); ips.add(s.getsockname()[0]); s.close()
    except Exception:
        pass
    try:
        for r in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET): ips.add(r[4][0])
    except Exception:
        pass
    nets = []
    for ip in ips:
        if ip.startswith(("127.", "169.254.")): continue
        nets.append(ipaddress.ip_network(ip + "/24", strict=False))
    return nets


def probe(host):
    for p in PORTS:
        try:
            with urllib.request.urlopen(f"http://{host}:{p}/api/ident", timeout=0.6) as r:
                j = json.load(r)
                if j.get("app") == "otsw":
                    return {"ip": host, "port": p, "name": j.get("name", ""), "sim": j.get("sim"), "ver": j.get("version", "")}
        except Exception:
            continue
    return None


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OT Switch Tool"); self.geometry("640x430"); self.minsize(560, 380)
        self.demo = None
        f = ttk.Frame(self, padding=12); f.pack(fill="both", expand=True)
        ttk.Label(f, text="OT Virtual Switch", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(f, text="Find your switch on the network, or try the GUI in demo mode.").pack(anchor="w", pady=(0, 8))
        box = ttk.LabelFrame(f, text="1. Find a switch on my network", padding=8); box.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(box, columns=("name", "ip", "mode"), show="headings", height=6)
        for c, t, w in (("name", "Switch name", 200), ("ip", "Address", 180), ("mode", "Mode", 120)):
            self.tree.heading(c, text=t); self.tree.column(c, width=w)
        self.tree.pack(fill="both", expand=True); self.tree.bind("<Double-1>", lambda e: self.open_sel())
        row = ttk.Frame(box); row.pack(fill="x", pady=(6, 0))
        self.scan_btn = ttk.Button(row, text="Scan network", command=self.scan); self.scan_btn.pack(side="left")
        ttk.Button(row, text="Open GUI in browser", command=self.open_sel).pack(side="left", padx=6)
        self.manual = ttk.Entry(row, width=18); self.manual.pack(side="right"); ttk.Label(row, text="or type IP:").pack(side="right", padx=4)
        self.status = tk.StringVar(value="Click 'Scan network'. (The switch's address is also shown on its console screen.)")
        ttk.Label(box, textvariable=self.status, foreground="#555").pack(anchor="w", pady=(4, 0))
        d = ttk.LabelFrame(f, text="2. Try it first (demo, nothing on your network is changed)", padding=8); d.pack(fill="x", pady=(10, 0))
        ttk.Button(d, text="Start demo and open GUI", command=self.start_demo).pack(side="left")
        ttk.Label(d, text="  login: admin / admin").pack(side="left")

    def scan(self):
        self.scan_btn.state(["disabled"]); self.tree.delete(*self.tree.get_children()); self.status.set("Scanning...")
        threading.Thread(target=self._scan, daemon=True).start()

    def _scan(self):
        hosts = [str(h) for n in local_subnets() for h in n.hosts()]
        found = []
        with concurrent.futures.ThreadPoolExecutor(80) as ex:
            for r in ex.map(probe, hosts):
                if r: found.append(r)
        self.after(0, lambda: self._done(found, len(hosts)))

    def _done(self, found, n):
        for r in found:
            self.tree.insert("", "end", values=(r["name"], f"{r['ip']}:{r['port']}", "DEMO" if r["sim"] else "Live"))
        self.status.set(f"Found {len(found)} switch(es) ({n} addresses checked)." if found else
                        f"No switch found ({n} addresses checked). Check cables / VM network, or type the IP.")
        self.scan_btn.state(["!disabled"])

    def open_sel(self):
        sel = self.tree.selection()
        if sel: addr = self.tree.item(sel[0])["values"][1]
        elif self.manual.get().strip(): addr = self.manual.get().strip()
        else: return messagebox.showinfo("OT Switch Tool", "Select a switch in the list or type its IP address.")
        webbrowser.open("http://" + addr)

    def start_demo(self):
        if not self.demo:
            try:
                os.environ["OTSW_PORT"] = "8080"; os.environ["OTSW_BIND"] = "127.0.0.1"
                import server
                from http.server import ThreadingHTTPServer
                self.demo = ThreadingHTTPServer(("127.0.0.1", 8080), server.H)
                threading.Thread(target=self.demo.serve_forever, daemon=True).start()
            except OSError:
                pass   # already running (or port in use by an earlier demo)
            except Exception as ex:
                return messagebox.showerror("OT Switch Tool", f"Could not start demo: {ex}")
        webbrowser.open("http://127.0.0.1:8080")


if __name__ == "__main__":
    App().mainloop()
