"""Modules, editions and licence keys for the OT Virtual Switch (Python standard library only).

A licence is a text token:  OTSW1.<base64url JSON>.<base64url Ed25519 signature>
The vendor signs it with a PRIVATE key that never ships; the appliance only contains the PUBLIC key below,
so customers cannot create their own keys.  (The app is plain Python: someone who edits the source can still
remove the checks - compile/obfuscate the build if you need stronger protection.)"""
import base64, hashlib, json, os, time

# >>> replace with your own key: run  python tools/otsw_licensor.py genkey   (it patches this line for you)
PUBKEY = "116877d72e1fe44fb496119fdf1253d1e70fc3e11039d6559db8292b906ca231"
EVAL_DAYS = 30

MODULES = [
    ("l2", "Layer 2 switching", "Spanning tree, port-channels (LACP), LLDP, IGMP snooping, port security, storm control, DHCP snooping, SPAN mirror, static MACs, rate limits"),
    ("l3", "Layer 3 routing", "VLAN gateways (SVI) and inter-VLAN routing, static routes, NAT, DHCP server and relay"),
    ("dyn", "Dynamic routing", "OSPF, RIP, BGP and VRRP gateway redundancy"),
    ("fw", "Firewall", "Zone-to-zone firewall between VLANs, WAN and VPN"),
    ("ot", "OT security", "Flow discovery, OT protocol recognition (Modbus, EtherNet/IP, S7, DNP3...), microsegmentation between devices"),
    ("vpn", "VPN server", "WireGuard remote access and site-to-site tunnels"),
]
KEYS = [m[0] for m in MODULES]
DEPS = {"dyn": ["l3"], "fw": ["l3"], "ot": ["fw"], "vpn": ["l3"]}
EDITIONS = [
    ("switch", "Virtual Switch", ["l2"], "Managed Layer 2 switch with VLANs, STP, LACP, port security and SPAN."),
    ("l3switch", "L3 Switch", ["l2", "l3"], "Layer 2 switch plus inter-VLAN routing, DHCP and NAT."),
    ("router", "Router", ["l3", "dyn"], "Static and dynamic routing (OSPF, RIP, BGP, VRRP), DHCP and NAT."),
    ("firewall", "Firewall + VPN", ["l3", "fw", "vpn"], "Zone firewall with NAT and a WireGuard VPN server."),
    ("otfw", "OT Firewall", ["l3", "fw", "ot", "vpn"], "Firewall with OT protocol discovery, microsegmentation and VPN."),
    ("full", "Everything", list(KEYS), "All modules."),
]


def close(mods, allowed):
    """Add the modules that the selected ones depend on; drop any whose dependency is not licensed."""
    s = {m for m in mods if m in allowed}
    for _ in range(4):
        for m in list(s):
            for d in DEPS.get(m, []):
                if d in allowed: s.add(d)
    for _ in range(4):
        for m in list(s):
            if any(d not in s for d in DEPS.get(m, [])): s.discard(m)
    return sorted(s, key=KEYS.index)


# ---------------------------------------------------------------- Ed25519 (RFC 8032 reference algorithm, pure Python)
_q = 2 ** 255 - 19
_l = 2 ** 252 + 27742317777372353535851937790883648493


def _H(m): return hashlib.sha512(m).digest()
def _inv(x): return pow(x, _q - 2, _q)


_d = -121665 * _inv(121666) % _q
_I = pow(2, (_q - 1) // 4, _q)


def _xrec(y):
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_q + 3) // 8, _q)
    if (x * x - xx) % _q: x = x * _I % _q
    return _q - x if x % 2 else x


_B = (_xrec(4 * _inv(5)) % _q, 4 * _inv(5) % _q)


def _add(P, Q):
    x1, y1 = P; x2, y2 = Q
    t = _d * x1 * x2 * y1 * y2
    return ((x1 * y2 + x2 * y1) * _inv(1 + t) % _q, (y1 * y2 + x1 * x2) * _inv(1 - t) % _q)


def _mul(P, e):
    Q = (0, 1)
    while e:
        if e & 1: Q = _add(Q, P)
        P = _add(P, P); e >>= 1
    return Q


def _enc(P): return (P[1] | ((P[0] & 1) << 255)).to_bytes(32, "little")


def _dec(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    x = _xrec(y)
    if (x & 1) != (s[31] >> 7): x = _q - x
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _q: raise ValueError("bad point")
    return (x, y)


def _Hint(m): return int.from_bytes(_H(m), "little")


def _scalar(sk):
    a = int.from_bytes(_H(sk)[:32], "little")
    return (a & ((1 << 254) - 8)) | (1 << 254)


def public_key(seed): return _enc(_mul(_B, _scalar(seed)))


def sign(seed, msg):
    h, a = _H(seed), _scalar(seed)
    A = _enc(_mul(_B, a))
    r = _Hint(h[32:] + msg)
    R = _enc(_mul(_B, r))
    S = (r + _Hint(R + A + msg) * a) % _l
    return R + S.to_bytes(32, "little")


def verify(pub, msg, sig):
    try:
        if len(sig) != 64 or len(pub) != 32: return False
        R, A, S = _dec(sig[:32]), _dec(pub), int.from_bytes(sig[32:], "little")
        if S >= _l: return False
        return _mul(_B, S) == _add(R, _mul(A, _Hint(sig[:32] + pub + msg)))
    except Exception:
        return False


# ---------------------------------------------------------------- tokens
def _b64(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def _unb64(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_token(seed, payload):
    body = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return "OTSW1." + _b64(body) + "." + _b64(sign(seed, body))


def read_token(tok, pub_hex=None):
    """-> (payload dict, error text)"""
    try:
        t, body, sig = tok.strip().split(".")
        if t != "OTSW1": return None, "not an OT Virtual Switch licence"
        raw = _unb64(body)
        if not verify(bytes.fromhex(pub_hex or PUBKEY), raw, _unb64(sig)): return None, "signature is not valid (wrong or altered key)"
        return json.loads(raw), ""
    except Exception:
        return None, "this does not look like a licence key"


def machine_id(sim=False):
    if sim: return "SIMULATION"
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            mid = open(p).read().strip()
            if mid: return hashlib.sha256(("otsw:" + mid).encode()).hexdigest()[:16].upper()
        except Exception:
            pass
    return "UNKNOWN"


class Licence:
    def __init__(self, data_dir, sim):
        self.dir, self.sim = data_dir, sim
        self.keyfile, self.evalfile = os.path.join(data_dir, "license.key"), os.path.join(data_dir, "eval.json")

    def install(self, tok):
        p, err = read_token(tok)
        if not p: raise ValueError(err)
        self._check(p)
        with open(self.keyfile, "w") as f: f.write(tok.strip() + "\n")
        return self.status()

    def remove(self):
        try: os.remove(self.keyfile)
        except OSError: pass

    def _check(self, p):
        hw = p.get("hw")
        if hw and hw.upper() != machine_id(self.sim): raise ValueError("this licence is for a different appliance (machine ID " + hw + ")")
        ex = p.get("expires")
        if ex and ex < time.strftime("%Y-%m-%d"): raise ValueError("this licence expired on " + ex)

    def status(self):
        hw = machine_id(self.sim)
        base = {"hw": hw, "eval_days": EVAL_DAYS}
        if self.sim:
            return dict(base, mode="demo", allowed=list(KEYS), customer="", edition="Demo", expires=None, note="Demo mode - everything is unlocked.")
        try:
            with open(self.keyfile) as f: tok = f.read()
        except OSError:
            tok = ""
        if tok:
            p, err = read_token(tok)
            if not p:
                return dict(base, mode="invalid", allowed=[], customer="", edition="", expires=None, note="Licence file invalid: " + err)
            try:
                self._check(p)
            except ValueError as ex:
                return dict(base, mode="expired", allowed=[], customer=p.get("customer", ""), edition=p.get("edition", ""), expires=p.get("expires"), note=str(ex))
            mods = [m for m in p.get("modules", []) if m in KEYS]
            return dict(base, mode="licensed", allowed=mods, customer=p.get("customer", ""), edition=p.get("edition", ""), expires=p.get("expires"), serial=p.get("id", ""), note="")
        try:
            with open(self.evalfile) as f: start = json.load(f)["start"]
        except Exception:
            start = time.time()
            try:
                os.makedirs(self.dir, exist_ok=True)
                with open(self.evalfile, "w") as f: json.dump({"start": start}, f)
            except OSError:
                pass
        left = EVAL_DAYS - int((time.time() - start) // 86400)
        if left > 0:
            return dict(base, mode="eval", allowed=list(KEYS), customer="", edition="Evaluation", expires=None, days_left=left, note=f"Evaluation - all modules unlocked for {left} more day(s).")
        return dict(base, mode="expired", allowed=[], customer="", edition="Evaluation", expires=None, note="The evaluation period has ended. Enter a licence key to continue using the modules.")
