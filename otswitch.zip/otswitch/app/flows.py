"""Flow discovery + OT protocol recognition for the OT Virtual Switch (Python standard library only).

* Listens (read-only, AF_PACKET) on every switch port and records who talks to whom:
  source, destination, protocol, port, VLAN/zone, ingress port, bytes, first/last seen.
* Reads the payload of common OT protocols (Modbus/TCP, EtherNet/IP + CIP, S7comm, DNP3, IEC 60870-5-104,
  OPC UA, BACnet/IP, OMRON FINS, PROFINET DCP/RT, GOOSE/SV ...) and records the *commands* seen,
  flagging write / control commands.
* Evaluates every learned flow against the firewall rules so the GUI can show Allowed / Blocked / not covered.
Detection of commands is passive: blocking is done by the firewall rules (host / port level)."""
import collections, ipaddress, json, os, select, socket, struct, threading, time

SOL_PACKET, PACKET_AUXDATA, PACKET_OUTGOING = 263, 8, 4
TCP, UDP, ICMP = 6, 17, 1

APP_PORTS = {
    502: "Modbus/TCP", 44818: "EtherNet/IP", 2222: "EtherNet/IP I/O", 102: "S7comm / MMS", 20000: "DNP3",
    2404: "IEC 60870-5-104", 4840: "OPC UA", 47808: "BACnet/IP", 9600: "OMRON FINS", 5006: "MELSEC", 5007: "MELSEC",
    1962: "PCWorx", 34962: "PROFINET", 34963: "PROFINET", 34964: "PROFINET", 1911: "Niagara Fox", 18245: "GE SRTP",
    80: "HTTP", 443: "HTTPS", 8080: "HTTP", 22: "SSH", 23: "Telnet", 21: "FTP", 3389: "RDP", 445: "SMB", 139: "NetBIOS",
    137: "NetBIOS", 138: "NetBIOS", 53: "DNS", 123: "NTP", 161: "SNMP", 162: "SNMP trap", 67: "DHCP", 68: "DHCP",
    5353: "mDNS", 1900: "SSDP", 514: "Syslog", 1883: "MQTT", 8883: "MQTT/TLS", 5900: "VNC", 135: "MS-RPC", 1433: "SQL Server",
}
OT_APPS = {"Modbus/TCP", "EtherNet/IP", "EtherNet/IP I/O", "S7comm / MMS", "S7comm", "DNP3", "IEC 60870-5-104", "OPC UA", "BACnet/IP",
           "OMRON FINS", "MELSEC", "PCWorx", "PROFINET", "Niagara Fox", "GE SRTP", "GOOSE", "Sampled Values", "EtherCAT",
           "POWERLINK", "SERCOS III", "MRP", "PTP"}
L2_TYPES = {0x8892: "PROFINET", 0x88B8: "GOOSE", 0x88BA: "Sampled Values", 0x88A4: "EtherCAT", 0x88AB: "POWERLINK",
            0x88CD: "SERCOS III", 0x88E3: "MRP", 0x88F7: "PTP"}

R, W, C, O = "read", "write", "control", "other"      # kind of a command


def _u16(b, o): return (b[o] << 8) | b[o + 1]
def _l16(b, o): return b[o] | (b[o + 1] << 8)


# ---------------------------------------------------------------- protocol readers: payload -> (app, function, kind)
MODBUS = {1: ("Read Coils", R), 2: ("Read Discrete Inputs", R), 3: ("Read Holding Registers", R), 4: ("Read Input Registers", R),
          5: ("Write Single Coil", W), 6: ("Write Single Register", W), 7: ("Read Exception Status", R), 8: ("Diagnostics", C),
          11: ("Get Comm Event Counter", R), 15: ("Write Multiple Coils", W), 16: ("Write Multiple Registers", W),
          17: ("Report Server ID", R), 20: ("Read File Record", R), 21: ("Write File Record", W), 22: ("Mask Write Register", W),
          23: ("Read/Write Multiple Registers", W), 24: ("Read FIFO Queue", R), 43: ("Read Device Identification", R)}


def p_modbus(p, req):
    if len(p) < 8 or p[2] or p[3] or _u16(p, 4) != len(p) - 6 or p[7] == 0:
        return None
    if not req: return ("Modbus/TCP", None, O)
    f = p[7] & 0x7F
    n, k = MODBUS.get(f, (f"Function {f}", O))
    return ("Modbus/TCP", n, k)


ENIP_CMD = {0x04: "List Services", 0x63: "List Identity", 0x64: "List Interfaces", 0x65: "Register Session",
            0x66: "Unregister Session", 0x6F: "Send RR Data", 0x70: "Send Unit Data"}
CIP = {0x01: ("Get Attributes All", R), 0x02: ("Set Attributes All", W), 0x03: ("Get Attribute List", R), 0x07: ("Reset", C),
       0x08: ("Create", W), 0x09: ("Delete", W), 0x0A: ("Multiple Service", O), 0x0E: ("Get Attribute Single", R),
       0x10: ("Set Attribute Single", W), 0x4C: ("Read Tag", R), 0x4D: ("Write Tag", W), 0x4E: ("Forward Close", O),
       0x52: ("Unconnected Send / Read Tag Frag", O), 0x53: ("Write Tag Fragmented", W), 0x54: ("Forward Open", O)}


def p_enip(p, req, udp_io=False):
    if udp_io: return ("EtherNet/IP I/O", "Cyclic I/O data", O)
    if len(p) < 24 or _l16(p, 0) not in ENIP_CMD: return None
    cmd = _l16(p, 0)
    if not req: return ("EtherNet/IP", None, O)
    name, kind = ENIP_CMD[cmd], O
    if cmd in (0x6F, 0x70) and len(p) >= 34:
        try:
            n, o = _l16(p, 30), 32
            for _ in range(min(n, 4)):
                t, ln = _l16(p, o), _l16(p, o + 2)
                d = p[o + 4:o + 4 + ln]
                if t == 0x00B2 and d: svc = d[0]
                elif t == 0x00B1 and len(d) > 2: svc = d[2]
                else: svc = None
                if svc is not None and not svc & 0x80:
                    name, kind = CIP.get(svc, (f"CIP service 0x{svc:02X}", O))
                    break
                o += 4 + ln
        except Exception:
            pass
    return ("EtherNet/IP", name, kind)


S7F = {0x00: ("CPU services", O), 0xF0: ("Setup communication", O), 0x04: ("Read Var", R), 0x05: ("Write Var", W),
       0x1A: ("Request download", W), 0x1B: ("Download block", W), 0x1C: ("Download ended", W), 0x1D: ("Start upload", R),
       0x1E: ("Upload", R), 0x1F: ("End upload", R), 0x28: ("PLC control (start/PI service)", C), 0x29: ("PLC STOP", C)}


def p_s7(p, req):
    if len(p) < 7 or p[0] != 3 or p[1]: return None
    if not req: return ("S7comm / MMS", None, O)
    pdu = p[5]
    if pdu == 0xE0: return ("S7comm / MMS", "COTP connect", O)
    if pdu == 0xF0 and len(p) > 5 + p[4]:
        s = 5 + p[4]
        if p[s] == 0x32 and len(p) > s + 10:
            if p[s + 1] in (1, 7):
                if p[s + 1] == 7: return ("S7comm", "Userdata (diagnostics / SZL)", O)
                n, k = S7F.get(p[s + 10], (f"S7 function 0x{p[s + 10]:02X}", O))
                return ("S7comm", n, k)
            return ("S7comm", None, O)
        return ("S7comm / MMS", "ISO-on-TCP / MMS data", O)
    return ("S7comm / MMS", None, O)


DNP3F = {1: ("Read", R), 2: ("Write", W), 3: ("Select", W), 4: ("Operate", W), 5: ("Direct Operate", W), 6: ("Direct Operate (no ack)", W),
         7: ("Immediate Freeze", O), 13: ("Cold Restart", C), 14: ("Warm Restart", C), 15: ("Initialize Data", W),
         17: ("Start Application", C), 18: ("Stop Application", C), 20: ("Enable Unsolicited", C), 21: ("Disable Unsolicited", C),
         22: ("Assign Class", W), 23: ("Delay Measurement", O), 24: ("Record Current Time", O)}


def p_dnp3(p, req):
    if len(p) < 10 or p[0] != 0x05 or p[1] != 0x64: return None
    if not req or len(p) < 13: return ("DNP3", None, O)
    f = p[12]
    if f >= 128: return ("DNP3", None, O)
    n, k = DNP3F.get(f, (f"Function {f}", O))
    return ("DNP3", n, k)


IEC = {45: ("Single command", W), 46: ("Double command", W), 47: ("Regulating step command", W), 48: ("Set-point (normalised)", W),
       49: ("Set-point (scaled)", W), 50: ("Set-point (float)", W), 51: ("Bitstring command", W), 100: ("Interrogation", O),
       101: ("Counter interrogation", O), 102: ("Read", R), 103: ("Clock synchronisation", C), 105: ("Reset process", C)}


def p_iec104(p, req):
    if len(p) < 6 or p[0] != 0x68: return None
    if p[2] & 3 == 3:
        n = {0x07: "STARTDT act", 0x0B: "STARTDT con", 0x13: "STOPDT act", 0x23: "STOPDT con", 0x43: "TESTFR act", 0x83: "TESTFR con"}
        return ("IEC 60870-5-104", n.get(p[2], "Control frame") if req else None, O)
    if len(p) >= 7 and p[2] & 1 == 0 and req:
        t = p[6]
        if 58 <= t <= 64: n, k = ("Command with time tag (type %d)" % t, W)
        elif t in IEC: n, k = IEC[t]
        elif t < 45: n, k = ("Monitoring data (type %d)" % t, O)
        else: n, k = (f"ASDU type {t}", O)
        return ("IEC 60870-5-104", n, k)
    return ("IEC 60870-5-104", None, O)


UA = {631: ("Read", R), 673: ("Write", W), 712: ("Call (method)", C), 527: ("Browse", R), 826: ("Publish", O), 787: ("Create Subscription", O),
      461: ("Create Session", O), 467: ("Activate Session", O), 664: ("History Read", R), 700: ("History Update", W)}


def p_opcua(p, req):
    if len(p) < 8 or p[:3] not in (b"HEL", b"ACK", b"OPN", b"MSG", b"CLO", b"ERR") or p[3:4] not in (b"F", b"C", b"E"): return None
    if not req: return ("OPC UA", None, O)
    m = p[:3]
    if m == b"HEL": return ("OPC UA", "Hello", O)
    if m == b"OPN": return ("OPC UA", "Open secure channel", O)
    if m == b"CLO": return ("OPC UA", "Close secure channel", O)
    if m == b"MSG":
        if len(p) >= 28 and p[24] == 0x01 and p[25] == 0:
            n, k = UA.get(_l16(p, 26), (None, O))
            if n: return ("OPC UA", n, k)
        return ("OPC UA", "Service message (encrypted or other)", O)
    return ("OPC UA", None, O)


BAC_C = {5: ("Subscribe COV", O), 12: ("ReadProperty", R), 14: ("ReadPropertyMultiple", R), 15: ("WriteProperty", W),
         16: ("WritePropertyMultiple", W), 17: ("DeviceCommunicationControl", C), 20: ("ReinitializeDevice", C)}
BAC_U = {0: ("I-Am", O), 1: ("I-Have", O), 2: ("COV Notification", O), 7: ("Who-Has", O), 8: ("Who-Is", O)}


def p_bacnet(p, req):
    if len(p) < 8 or p[0] != 0x81: return None
    o = 10 if p[1] == 0x04 else 4
    try:
        if p[o] != 1: return None
        ctl, o = p[o + 1], o + 2
        if ctl & 0x20: o += 3 + p[o + 2]
        if ctl & 0x08: o += 3 + p[o + 2]
        if ctl & 0x20: o += 1
        if ctl & 0x80: return ("BACnet/IP", "Network layer message", O)
        t = p[o] >> 4
        if t == 0:
            sv = p[o + 5] if p[o] & 0x08 else p[o + 3]
            n, k = BAC_C.get(sv, (f"Confirmed service {sv}", O))
            return ("BACnet/IP", n, k)
        if t == 1:
            n, k = BAC_U.get(p[o + 1], (f"Unconfirmed service {p[o + 1]}", O))
            return ("BACnet/IP", n, k)
    except IndexError:
        pass
    return ("BACnet/IP", None, O)


FINS = {(1, 1): ("Memory area read", R), (1, 2): ("Memory area write", W), (1, 3): ("Memory area fill", W), (4, 1): ("Run", C),
        (4, 2): ("Stop", C), (5, 1): ("Controller data read", R), (7, 1): ("Clock read", R), (0x21, 2): ("Error log clear", C)}


def p_fins(p, req):
    o = 16 if p[:4] == b"FINS" else 0
    if len(p) < o + 12 or p[o] not in (0x80, 0x81, 0xC0, 0xC1, 0x40, 0x41): return None
    if not req or p[o] & 0x40: return ("OMRON FINS", None, O)
    n, k = FINS.get((p[o + 10], p[o + 11]), (f"Command {p[o + 10]:02X}{p[o + 11]:02X}", O))
    return ("OMRON FINS", n, k)


READERS = {502: p_modbus, 44818: p_enip, 102: p_s7, 20000: p_dnp3, 2404: p_iec104, 4840: p_opcua, 47808: p_bacnet, 9600: p_fins}


def p_l2(et, p):
    app = L2_TYPES[et]
    if et == 0x8892 and len(p) >= 3:
        fid = _u16(p, 0)
        if fid in (0xFEFD, 0xFEFE, 0xFEFF):
            sv = {3: ("DCP Get", R), 4: ("DCP Set (changes name/IP)", W), 5: ("DCP Identify", O)}.get(p[2], ("DCP", O))
            return app, sv[0], sv[1]
        if 0x8000 <= fid <= 0xBFFF: return app, "Cyclic I/O (RT)", O
        return app, "Acyclic / alarm", O
    return app, None, O


# ---------------------------------------------------------------- packet parsing
def parse(frame):
    """frame (bytes) -> dict or None.  Reads Ethernet / VLAN / IPv4 / TCP / UDP and the OT payload."""
    if len(frame) < 14: return None
    dmac, smac, et, o, vlan = frame[0:6], frame[6:12], _u16(frame, 12), 14, None
    while et in (0x8100, 0x88A8) and len(frame) >= o + 4:
        vlan, et, o = _u16(frame, o) & 0x0FFF, _u16(frame, o + 2), o + 4
    d = {"smac": ":".join("%02x" % x for x in smac), "dmac": ":".join("%02x" % x for x in dmac), "vlan": vlan, "len": len(frame)}
    if et in L2_TYPES:
        app, fn, kind = p_l2(et, frame[o:])
        d.update(l2=True, app=app, fn=fn, kind=kind, proto="l2", port=0, src=d["smac"], dst=d["dmac"])
        return d
    if et != 0x0800 or len(frame) < o + 20 or frame[o] >> 4 != 4: return None
    ihl = (frame[o] & 15) * 4
    if ihl < 20 or len(frame) < o + ihl: return None
    if _u16(frame, o + 6) & 0x1FFF: return None                       # later fragment
    proto = frame[o + 9]
    src, dst = socket.inet_ntoa(frame[o + 12:o + 16]), socket.inet_ntoa(frame[o + 16:o + 20])
    d.update(l2=False, src=src, dst=dst, fn=None, kind=O)
    t = o + ihl
    if proto == ICMP:
        d.update(proto="icmp", port=0, app="ICMP", client=True)
        return d
    if proto not in (TCP, UDP) or len(frame) < t + 8: return None
    sp, dp = _u16(frame, t), _u16(frame, t + 2)
    if proto == TCP:
        if len(frame) < t + 20: return None
        fl = frame[t + 13]
        pay = frame[t + (frame[t + 12] >> 4) * 4:]
        syn = bool(fl & 2) and not fl & 16
    else:
        pay, syn = frame[t + 8:], False
    d["proto"] = "tcp" if proto == TCP else "udp"
    # which side is the server?
    ksp, kdp = sp in APP_PORTS or sp in READERS, dp in APP_PORTS or dp in READERS
    if kdp and not ksp: client = True
    elif ksp and not kdp: client = False
    elif syn: client = True
    else: client = sp >= dp
    d["client"] = client
    sport = dp if client else sp
    d["port"] = sport
    d["cport"] = sp if client else dp
    d["app"] = APP_PORTS.get(sport) or (f"{d['proto'].upper()}/{sport}")
    if sport == 2222 and proto == UDP: d["app"] = "EtherNet/IP I/O"
    if pay:
        try:
            if proto == UDP and sport == 2222: r = p_enip(pay, client, udp_io=True)
            elif sport in READERS: r = READERS[sport](pay, client) if not (proto == UDP and sport in (502, 102, 2404, 4840)) else None
            else: r = None
        except Exception:
            r = None
        if r:
            d["app"], d["fn"], d["kind"] = r[0], r[1], r[2]
    return d


# ---------------------------------------------------------------- the flow table
def _is_multi(ip):
    try:
        a = ipaddress.ip_address(ip)
        return a.is_multicast or ip.endswith(".255") or ip == "255.255.255.255" or ip == "0.0.0.0"
    except Exception:
        return False


class Flows:
    def __init__(self, path=None, max_flows=4000):
        self.path, self.max = path, max_flows
        self.lock = threading.Lock()
        self.flows, self.hosts = {}, {}
        self.alerts = collections.deque(maxlen=200)
        self.dirty = False
        self.started = time.time()
        self.load()

    # ---- persistence
    def load(self):
        try:
            with open(self.path) as f:
                j = json.load(f)
            for k, v in j.get("flows", {}).items():
                v["ports"] = set(v.get("ports", []))
                self.flows[k] = v
            self.hosts = j.get("hosts", {})
        except Exception:
            pass

    def save(self):
        if not self.path or not self.dirty: return
        with self.lock:
            j = {"flows": {k: dict(v, ports=sorted(v["ports"])) for k, v in self.flows.items()}, "hosts": self.hosts}
            self.dirty = False
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w") as f: json.dump(j, f)
            os.replace(tmp, self.path)
        except Exception:
            pass

    def clear(self):
        with self.lock:
            self.flows.clear(); self.hosts.clear(); self.alerts.clear(); self.dirty = True

    # ---- recording
    def record(self, d, port, now=None):
        now = now or time.time()
        if d.get("l2"):
            key = f"L2|{d['src']}|{d['dst']}|{d['app']}"
        else:
            key = f"{d['src']}|{d['dst']}|{d['proto']}|{d['port']}" if d["client"] else f"{d['dst']}|{d['src']}|{d['proto']}|{d['port']}"
        with self.lock:
            if not d.get("l2") and d["client"]:
                self.hosts[d["src"]] = {"mac": d["smac"], "vlan": d["vlan"], "port": port, "t": now}
            elif not d.get("l2") and d["src"] not in self.hosts:
                self.hosts[d["src"]] = {"mac": d["smac"], "vlan": d["vlan"], "port": port, "t": now}
            f = self.flows.get(key)
            if f is None:
                if len(self.flows) >= self.max:
                    old = min(self.flows, key=lambda k: self.flows[k]["last"])
                    del self.flows[old]
                a, b = (d["src"], d["dst"]) if d.get("l2") or d["client"] else (d["dst"], d["src"])
                f = {"src": a, "dst": b, "proto": d["proto"], "port": d["port"], "app": d["app"], "l2": bool(d.get("l2")),
                     "vlan": d["vlan"], "ports": set(), "pkts": 0, "bytes": 0, "first": now, "last": now, "funcs": {}, "writes": 0,
                     "bc": (not d.get("l2")) and _is_multi(d["dst"] if d["client"] else d["src"]) or (d.get("l2") and d["dmac"] == "ff:ff:ff:ff:ff:ff"),
                     "mc": 0}
                self.flows[key] = f
                if not f["bc"]:
                    self.alerts.append({"t": now, "kind": "new", "msg": f"New flow {a} -> {b}  {d['app']}" + (f" ({d['proto']}/{d['port']})" if not d.get("l2") else "")})
            if d["app"] != f["app"] and d["app"] not in ("ICMP",) and (d.get("fn") or d["app"] in OT_APPS):
                f["app"] = d["app"]
            if f["vlan"] is None and d["vlan"] is not None: f["vlan"] = d["vlan"]
            f["pkts"] += 1
            f["bytes"] += d["len"]
            f["last"] = now
            f["ports"].add(port)
            if d.get("fn") and (d.get("l2") or d["client"]):
                n = d["fn"]
                new = n not in f["funcs"]
                f["funcs"][n] = f["funcs"].get(n, 0) + 1
                if d["kind"] in (W, C):
                    f["writes"] += 1
                    f.setdefault("wfuncs", {})
                    if n not in f["wfuncs"]:
                        f["wfuncs"][n] = now
                        self.alerts.append({"t": now, "kind": "write", "msg": f"{d['kind'].upper()} command '{n}' ({d['app']})  {f['src']} -> {f['dst']}"})
            self.dirty = True

    def process(self, frame, port, vlan_default=None, now=None):
        d = parse(frame)
        if not d: return
        if d["vlan"] is None: d["vlan"] = vlan_default
        self.record(d, port, now)

    # ---- report
    def snapshot(self, cfg):
        nets = []
        for s in cfg.get("svis", []):
            try: nets.append((s["vlan"], ipaddress.ip_interface(s["ip"]).network))
            except Exception: pass
        gw = {}
        for s in cfg.get("svis", []):
            try: gw[str(ipaddress.ip_interface(s["ip"]).ip)] = s["vlan"]
            except Exception: pass

        def zone(ip, vl):
            if ip in gw: return gw[ip]
            try: a = ipaddress.ip_address(ip)
            except Exception: return vl
            for v, n in nets:
                if a in n: return v
            h = self.hosts.get(ip)
            return h.get("vlan") if h and h.get("vlan") is not None else None
        out, mat = [], {}
        with self.lock:
            items = [(k, dict(v, ports=sorted(v["ports"]))) for k, v in self.flows.items()]
            hosts = {k: dict(v) for k, v in self.hosts.items()}
        for k, f in items:
            f["key"] = k
            if f["l2"]:
                f["szone"] = f["dzone"] = f["vlan"]
                f["verdict"], f["rule"], f["by"] = "l2", 0, ""
            else:
                f["szone"], f["dzone"] = zone(f["src"], f["vlan"]), zone(f["dst"], None)
                f["verdict"], f["rule"], f["by"] = evaluate(f, cfg)
            f["smac"] = (hosts.get(f["src"]) or {}).get("mac", "")
            f["dmac"] = (hosts.get(f["dst"]) or {}).get("mac", "")
            f["ot"] = f["app"] in OT_APPS
            out.append(f)
            if not f["bc"]:
                m = mat.setdefault((f["szone"], f["dzone"]), {"src": f["szone"], "dst": f["dzone"], "flows": 0, "bytes": 0, "accept": 0, "drop": 0, "writes": 0, "ot": 0})
                m["flows"] += 1; m["bytes"] += f["bytes"]; m["writes"] += 1 if f["writes"] else 0; m["ot"] += 1 if f["ot"] else 0
                if f["verdict"] == "accept": m["accept"] += 1
                elif f["verdict"] == "drop": m["drop"] += 1
        out.sort(key=lambda f: -f["last"])
        return {"flows": out, "matrix": list(mat.values()), "hosts": len(hosts), "alerts": list(self.alerts)[-60:][::-1], "now": time.time(), "since": self.started}


def _in(ip, net):
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network(net, strict=False)
    except Exception:
        return False


def _port_ok(spec, p):
    if not spec: return True
    a, _, b = str(spec).partition("-")
    try: return int(a) <= p <= int(b or a)
    except Exception: return False


def evaluate(f, cfg):
    """-> (verdict 'accept'|'drop', rule number (1-based) or 0, 'rule'|'default').  Mirrors the generated nftables rules."""
    fw = cfg.get("firewall", {})
    same = f["szone"] is not None and f["szone"] == f["dzone"]
    sz = "wan" if f["szone"] is None else str(f["szone"])
    dz = "wan" if f["dzone"] is None else str(f["dzone"])
    for n, r in enumerate(fw.get("rules", []), 1):
        if same and not (r.get("src_ip") or r.get("dst_ip")): continue
        if not same:
            if r.get("src", "any") not in ("any", sz): continue
            if r.get("dst", "any") not in ("any", dz): continue
        if r.get("src_ip") and not _in(f["src"], r["src_ip"]): continue
        if r.get("dst_ip") and not _in(f["dst"], r["dst_ip"]): continue
        rp = r.get("proto", "any")
        if rp != "any" and rp != f["proto"]: continue
        if r.get("port") and (f["proto"] not in ("tcp", "udp") or not _port_ok(r["port"], f["port"])): continue
        return r["action"], n, "rule"
    return (fw.get("l2_default", "accept") if same else fw.get("default_forward", "drop")), 0, "default"


# ---------------------------------------------------------------- live capture
class Sniffer(threading.Thread):
    """One thread, one raw socket per switch port. Read-only; ignores frames the switch itself transmits."""
    def __init__(self, flows, get_ports):
        super().__init__(daemon=True)
        self.flows, self.get_ports = flows, get_ports
        self.socks, self.err = {}, ""
        self.enabled = True

    def _sync(self):
        want = self.get_ports() if self.enabled else {}
        for i in list(self.socks):
            if i not in want:
                try: self.socks[i][0].close()
                except Exception: pass
                del self.socks[i]
        for i, info in want.items():
            if i in self.socks:
                self.socks[i] = (self.socks[i][0], info)
                continue
            try:
                s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3))
                s.setsockopt(SOL_PACKET, PACKET_AUXDATA, 1)
                s.bind((i, 0)); s.setblocking(False)
                self.socks[i] = (s, info); self.err = ""
            except Exception as ex:
                self.err = f"{i}: {ex}"

    def run(self):
        last = 0
        while True:
            try:
                if time.time() - last > 5:
                    self._sync(); last = time.time()
                if not self.socks:
                    time.sleep(1); continue
                by = {v[0]: (k, v[1]) for k, v in self.socks.items()}
                r, _, _ = select.select(list(by), [], [], 1.0)
                for s in r:
                    for _ in range(200):
                        try: data, anc, flg, addr = s.recvmsg(2048, 128)
                        except (BlockingIOError, OSError): break
                        if addr[2] == PACKET_OUTGOING: continue
                        port, info = by[s][1]["id"], by[s][1]
                        vlan = None
                        for lvl, typ, cd in anc:
                            if lvl == SOL_PACKET and typ == PACKET_AUXDATA and len(cd) >= 20:
                                st, tci = struct.unpack_from("=I", cd, 0)[0], struct.unpack_from("=H", cd, 16)[0]
                                if st & (1 << 4) and tci & 0xFFF: vlan = tci & 0xFFF
                        self.flows.process(data, port, vlan if vlan else info.get("pvid"))
            except Exception as ex:
                self.err = str(ex)
                time.sleep(1)


class Saver(threading.Thread):
    def __init__(self, flows):
        super().__init__(daemon=True); self.flows = flows

    def run(self):
        while True:
            time.sleep(30)
            self.flows.save()


# ---------------------------------------------------------------- simulation (demo mode)
class Demo(threading.Thread):
    """Feeds believable traffic into the table when the switch runs in simulation, so the GUI can be tried anywhere."""
    def __init__(self, flows):
        super().__init__(daemon=True); self.flows = flows

    def run(self):
        import random
        F = self.flows
        macs = {"192.168.10.5": "00:1d:9c:aa:01:10", "192.168.10.6": "00:0e:8c:11:22:33", "192.168.20.10": "00:0c:29:5e:77:21",
                "192.168.20.11": "00:0c:29:5e:77:22", "192.168.20.50": "b8:27:eb:11:22:33", "192.168.10.1": "02:00:00:00:00:01"}
        vl = lambda ip: 10 if ip.startswith("192.168.10.") else 20
        pr = lambda ip: 2 if ip == "192.168.10.5" else 3 if ip == "192.168.10.6" else 4 if ip == "192.168.20.10" else 5
        for ip, m in macs.items(): F.hosts[ip] = {"mac": m, "vlan": vl(ip), "port": pr(ip), "t": time.time()}

        def pkt(src, dst, proto, port, app, fn, kind, n=1, ln=90, rev=False):
            d = {"smac": macs.get(src, "00:00:00:00:00:00"), "dmac": macs.get(dst, "00:00:00:00:00:00"), "vlan": vl(src), "len": ln, "l2": False,
                 "src": src, "dst": dst, "proto": proto, "port": port, "app": app, "fn": fn, "kind": kind, "client": True}
            for _ in range(n): F.record(d, pr(src))
        tick = 0
        while True:
            tick += 1
            pkt("192.168.20.10", "192.168.10.5", "tcp", 44818, "EtherNet/IP", "Read Tag", R, 40, 120)
            pkt("192.168.20.10", "192.168.10.5", "tcp", 44818, "EtherNet/IP", "Send Unit Data" if tick % 5 else "Forward Open", O, 10, 110)
            pkt("192.168.20.11", "192.168.10.6", "tcp", 502, "Modbus/TCP", "Read Holding Registers", R, 30, 80)
            if tick in (3, 11, 25): pkt("192.168.20.11", "192.168.10.6", "tcp", 502, "Modbus/TCP", "Write Single Register", W, 1, 80)
            pkt("192.168.10.5", "192.168.10.6", "tcp", 502, "Modbus/TCP", "Read Input Registers", R, 12, 80)
            pkt("192.168.20.50", "192.168.10.5", "tcp", 102, "S7comm", "Read Var", R, 6, 100)
            if tick in (4, 12): pkt("192.168.20.50", "192.168.10.5", "tcp", 102, "S7comm", "Write Var", W, 1, 100)
            if tick == 8: pkt("192.168.20.50", "192.168.10.5", "tcp", 102, "S7comm", "PLC STOP", C, 1, 100)
            if tick >= 6: pkt("192.168.20.50", "192.168.10.6", "tcp", 3389, "RDP", None, O, 25, 600)
            if tick >= 9: pkt("192.168.20.50", "192.168.10.5", "icmp", 0, "ICMP", None, O, 3, 74)
            if tick >= 14: pkt("192.168.20.11", "192.168.10.1", "tcp", 22, "SSH", None, O, 8, 200)
            time.sleep(3)
