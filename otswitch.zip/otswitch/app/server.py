#!/usr/bin/env python3
"""OT Virtual Switch - GUI-managed L2/L3 switch on top of the Linux bridge.

Python 3 standard library only. Run as root on Linux (appliance image, Raspberry Pi,
laptop, VM) to really configure the kernel. Anywhere else (or without root) it runs in
SIMULATION mode: the GUI works fully, commands are only logged.
"""
import base64, collections, hashlib, hmac, ipaddress, json, os, re, secrets, shutil, signal, subprocess, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

VERSION = "1.1.0"
BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
IS_LINUX_ROOT = sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0 and bool(shutil.which("ip"))
SIM = os.environ.get("OTSW_SIM") == "1" or not IS_LINUX_ROOT
DATA = os.environ.get("OTSW_DATA") or ("/var/lib/otsw" if IS_LINUX_ROOT and not SIM else os.path.dirname(os.path.abspath(__file__)))
os.makedirs(DATA, exist_ok=True)
CFG_FILE = os.environ.get("OTSW_CONFIG", os.path.join(DATA, "config.json"))
APPLIED_FILE = os.path.join(DATA, "applied.json")
AUTH_FILE = os.path.join(DATA, "auth.json")
DNSMASQ_CONF = os.path.join(DATA, "dnsmasq.conf")
DNSMASQ_PID = os.path.join(DATA, "dnsmasq.pid")
LEASES = os.path.join(DATA, "dnsmasq.leases")
BR = "br0"
USER = os.environ.get("OTSW_USER", "admin")
DEFAULT_PASSWORD = os.environ.get("OTSW_PASSWORD", "admin")

LOCK = threading.Lock()
LOG = collections.deque(maxlen=500)
IFRE = re.compile(r"^[A-Za-z0-9_.\-]{1,15}$")
NAMERE = re.compile(r"^[\w .\-]{1,32}$")


def log(msg):
    LOG.append(time.strftime("%H:%M:%S ") + msg)


# ---------------------------------------------------------------- config
def default_config():
    return {
        "name": "OT-SW1",
        "routing": True,
        "stp": False,
        "ports": [
            {"id": i, "label": f"Gi1/{i}", "kind": "virtual", "iface": "", "mode": "access",
             "vlan": 1, "native": 1, "allowed": [], "admin": True, "desc": ""}
            for i in range(1, 9)
        ],
        "vlans": [{"id": 1, "name": "default"}, {"id": 10, "name": "PLC"},
                  {"id": 20, "name": "HMI"}, {"id": 99, "name": "MGMT"}],
        "svis": [{"vlan": 10, "ip": "192.168.10.1/24", "enabled": True},
                 {"vlan": 20, "ip": "192.168.20.1/24", "enabled": True}],
        "routes": [],
        "dhcp": [],
        "mirror": {"enabled": False, "sources": [], "dest": 0},
        "firewall": {"default_forward": "drop", "rules": [
            {"src": "20", "dst": "10", "proto": "tcp", "port": "44818", "action": "accept",
             "comment": "HMI to PLC (EtherNet/IP)"}],
            "nat": {"enabled": False, "wan": "eth0"}},
    }


def upgrade(c):
    d = default_config()
    for k in ("stp", "dhcp", "mirror", "routes", "svis"):
        c.setdefault(k, d[k])
    c["firewall"].setdefault("nat", d["firewall"]["nat"])
    return c


def load_cfg():
    try:
        with open(CFG_FILE) as f:
            return upgrade(json.load(f))
    except Exception:
        c = default_config()
        save_cfg(c)
        return c


def save_cfg(c):
    tmp = CFG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(c, f, indent=2)
    os.replace(tmp, CFG_FILE)


def chash(c):
    return hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest()


def load_applied():
    try:
        with open(APPLIED_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def port_iface(p):
    return f"otsw-p{p['id']}" if p["kind"] == "virtual" else p["iface"]


# ---------------------------------------------------------------- auth
def pw_hash(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 120000).hex()


def auth_ok(user, pw):
    try:
        with open(AUTH_FILE) as f:
            a = json.load(f)
        return hmac.compare_digest(user, a["user"]) and hmac.compare_digest(pw_hash(pw, a["salt"]), a["hash"])
    except FileNotFoundError:
        return hmac.compare_digest(user, USER) and hmac.compare_digest(pw, DEFAULT_PASSWORD)
    except Exception:
        return False


def default_pw_in_use():
    return not os.path.exists(AUTH_FILE) and DEFAULT_PASSWORD == "admin"


def set_password(new):
    if len(new) < 6:
        raise ValueError("Password must be at least 6 characters")
    salt = secrets.token_hex(16)
    tmp = AUTH_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"user": USER, "salt": salt, "hash": pw_hash(new, salt)}, f)
    os.chmod(tmp, 0o600)
    os.replace(tmp, AUTH_FILE)


# ---------------------------------------------------------------- system helpers
def sh(args, stdin=None, ignore=False):
    log("$ " + " ".join(args) + ("   <script>" if stdin else ""))
    if SIM:
        return ""
    try:
        r = subprocess.run(args, input=stdin, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        if ignore:
            return ""
        raise RuntimeError(f"'{args[0]}' is not installed on this device")
    if r.returncode and not ignore:
        raise RuntimeError(f"{' '.join(args)} -> {r.stderr.strip() or r.stdout.strip()}")
    return r.stdout


def quiet(args):
    if SIM:
        return ""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=20)
    except Exception:
        return ""
    return r.stdout if r.returncode == 0 else ""


def default_route_iface():
    if SIM:
        return ""
    try:
        for r in json.loads(quiet(["ip", "-j", "route", "show", "default"]) or "[]"):
            return r.get("dev", "")
    except Exception:
        pass
    return ""


def read_stat(i, name):
    try:
        with open(f"/sys/class/net/{i}/{name}") as f:
            return f.read().strip()
    except Exception:
        return ""


def list_nics():
    """Existing network adapters offered in the port drop-down."""
    mgmt = default_route_iface()
    if SIM:
        return [{"name": n, "mac": m, "speed": s, "state": st, "mgmt": n == "eth0"} for n, m, s, st in
                [("eth0", "00:0c:29:aa:00:01", 1000, "up"), ("eth1", "00:0c:29:aa:00:02", 1000, "up"),
                 ("eth2", "00:0c:29:aa:00:03", 1000, "down"), ("enx001122334455", "00:11:22:33:44:55", 100, "up")]]
    out = []
    try:
        for n in sorted(os.listdir("/sys/class/net")):
            if n in ("lo", BR) or n.startswith(("veth", "docker", "vlan", "otsw-", "tap", "virbr", "br-", "wl", "ww", "tun")):
                continue
            if not os.path.exists(f"/sys/class/net/{n}/device") and not n.startswith("eth"):
                continue
            sp = read_stat(n, "speed")
            out.append({"name": n, "mac": read_stat(n, "address"),
                        "speed": int(sp) if sp.lstrip("-").isdigit() and int(sp) > 0 else 0,
                        "state": read_stat(n, "operstate") or "unknown", "mgmt": n == mgmt})
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- validation
def validate(c):
    e = []
    if not isinstance(c, dict):
        raise ValueError("bad config")
    c = upgrade(c)
    if not NAMERE.match(str(c.get("name", ""))):
        e.append("Switch name: 1-32 letters/digits/space/-/_")
    vids = []
    for v in c.get("vlans", []):
        try:
            i = int(v["id"])
        except Exception:
            e.append("VLAN id must be a number"); continue
        if not 1 <= i <= 4094: e.append(f"VLAN {i}: id must be 1-4094")
        if i in vids: e.append(f"VLAN {i}: duplicate")
        if not NAMERE.match(str(v.get("name", ""))): e.append(f"VLAN {i}: invalid name")
        vids.append(i)
    if 1 not in vids: e.append("VLAN 1 must exist")
    ports = c.get("ports", [])
    if not 1 <= len(ports) <= 48: e.append("Port count must be 1-48")
    ids, ifs = set(), set()
    mgmt = default_route_iface()
    for p in ports:
        pid = p.get("id")
        if not isinstance(pid, int) or pid < 1 or pid in ids: e.append(f"Port id {pid}: invalid/duplicate"); continue
        ids.add(pid)
        if p.get("kind") not in ("virtual", "physical"): e.append(f"Port {pid}: bad type")
        if p.get("mode") not in ("access", "trunk"): e.append(f"Port {pid}: bad mode")
        if not re.match(r"^[\w ./\-]{1,16}$", str(p.get("label", ""))): e.append(f"Port {pid}: invalid label")
        if p.get("kind") == "physical":
            n = p.get("iface", "")
            if not IFRE.match(n): e.append(f"Port {pid}: choose a network adapter")
            elif n in ifs: e.append(f"Port {pid}: adapter {n} already used")
            elif n == mgmt: e.append(f"Port {pid}: {n} carries this device's management connection - using it would lock you out")
            ifs.add(n)
        if p.get("vlan") not in vids: e.append(f"Port {pid}: VLAN {p.get('vlan')} does not exist")
        if p.get("mode") == "trunk":
            if p.get("native") not in vids: e.append(f"Port {pid}: native VLAN does not exist")
            for a in p.get("allowed", []):
                if a not in vids: e.append(f"Port {pid}: allowed VLAN {a} does not exist")
    svi_net = {}
    for s in c.get("svis", []):
        if s.get("vlan") not in vids: e.append(f"L3 interface: VLAN {s.get('vlan')} does not exist")
        if s.get("vlan") in svi_net: e.append(f"L3 interface: VLAN {s.get('vlan')} defined twice")
        try:
            ii = ipaddress.ip_interface(s.get("ip", ""))
            if ii.version != 4: raise ValueError
            svi_net[s.get("vlan")] = ii
        except Exception:
            svi_net[s.get("vlan")] = None
            e.append(f"VLAN {s.get('vlan')}: IP must look like 192.168.1.1/24")
    for r in c.get("routes", []):
        try:
            d = r["dest"].strip()
            ipaddress.ip_network("0.0.0.0/0" if d == "default" else d, strict=False)
            ipaddress.ip_address(r["via"].strip())
        except Exception:
            e.append(f"Route {r.get('dest')} via {r.get('via')}: invalid")
    seen = set()
    for d in c.get("dhcp", []):
        v = d.get("vlan")
        if v in seen: e.append(f"DHCP VLAN {v}: defined twice")
        seen.add(v)
        ii = svi_net.get(v)
        if ii is None:
            e.append(f"DHCP VLAN {v}: the VLAN needs an L3 interface with a valid IP first"); continue
        try:
            a, b = ipaddress.ip_address(d["start"]), ipaddress.ip_address(d["end"])
            if a not in ii.network or b not in ii.network or int(a) > int(b):
                raise ValueError
            if ii.ip == a or ii.ip == b or (int(a) <= int(ii.ip) <= int(b)):
                e.append(f"DHCP VLAN {v}: range must not include the gateway {ii.ip}")
        except Exception:
            e.append(f"DHCP VLAN {v}: start/end must be inside {ii.network} and start <= end")
        if not (isinstance(d.get("lease"), int) and 1 <= d["lease"] <= 720): e.append(f"DHCP VLAN {v}: lease 1-720 hours")
        if d.get("dns"):
            try: ipaddress.ip_address(d["dns"])
            except Exception: e.append(f"DHCP VLAN {v}: DNS server invalid")
    m = c.get("mirror", {})
    if m.get("enabled"):
        if m.get("dest") not in ids: e.append("Mirror: choose a destination port")
        if not m.get("sources"): e.append("Mirror: choose at least one source port")
        for s in m.get("sources", []):
            if s not in ids: e.append(f"Mirror: source port {s} does not exist")
            if s == m.get("dest"): e.append("Mirror: destination cannot also be a source")
    fw = c.get("firewall", {})
    if fw.get("default_forward") not in ("accept", "drop"): e.append("Firewall: default policy must be accept/drop")
    for n, r in enumerate(fw.get("rules", []), 1):
        for k in ("src", "dst"):
            if r.get(k) not in ("any", "wan") and not (str(r.get(k, "")).isdigit() and int(r[k]) in vids):
                e.append(f"Rule {n}: bad {k}")
        if r.get("proto") not in ("any", "tcp", "udp", "icmp"): e.append(f"Rule {n}: bad protocol")
        if r.get("port") and not re.match(r"^\d{1,5}(-\d{1,5})?$", str(r["port"])): e.append(f"Rule {n}: bad port")
        if r.get("action") not in ("accept", "drop"): e.append(f"Rule {n}: bad action")
    nat = fw.get("nat", {})
    if nat.get("enabled") and not IFRE.match(str(nat.get("wan", ""))): e.append("NAT: invalid WAN adapter")
    if e:
        raise ValueError("; ".join(e))
    return c


# ---------------------------------------------------------------- apply
def current_vids(iface):
    out = quiet(["bridge", "-j", "vlan", "show", "dev", iface])
    try:
        return [v["vlan"] for d in json.loads(out or "[]") for v in d.get("vlans", [])]
    except Exception:
        return []


def build_nft(c):
    fw = c["firewall"]
    wan = fw.get("nat", {}).get("wan", "")

    def ifn(x):
        return wan if x == "wan" else f"vlan{x}"
    lines = ["table inet otsw", "delete table inet otsw", "table inet otsw {",
             "  chain forward {", f"    type filter hook forward priority 0; policy {fw['default_forward']};",
             "    ct state established,related accept"]
    for r in fw["rules"]:
        m = ""
        if r["src"] != "any": m += f' iifname "{ifn(r["src"])}"'
        if r["dst"] != "any": m += f' oifname "{ifn(r["dst"])}"'
        if r["proto"] == "icmp": m += " meta l4proto { icmp, ipv6-icmp }"
        elif r["proto"] in ("tcp", "udp"):
            m += f" {r['proto']} dport {r['port']}" if r.get("port") else f" meta l4proto {r['proto']}"
        cm = re.sub(r'[^\w .\-]', "", r.get("comment", ""))[:60]
        lines.append(f'   {m} {r["action"]}' + (f' comment "{cm}"' if cm else ""))
    lines += ["  }", "}"]
    lines += ["table ip otsw_nat", "delete table ip otsw_nat"]
    if fw.get("nat", {}).get("enabled"):
        lines += ["table ip otsw_nat {", "  chain post {", "    type nat hook postrouting priority 100;",
                  f'    oifname "{wan}" masquerade', "  }", "}"]
    return "\n".join(lines) + "\n"


def build_dnsmasq(c):
    ips = {s["vlan"]: ipaddress.ip_interface(s["ip"]) for s in c["svis"] if s["enabled"]}
    out = ["port=0", "bind-dynamic", "except-interface=lo", f"dhcp-leasefile={LEASES}", "dhcp-authoritative", "log-dhcp"]
    n = 0
    for d in c["dhcp"]:
        ii = ips.get(d["vlan"])
        if not ii:
            continue
        t = f"v{d['vlan']}"
        n += 1
        out += [f"interface=vlan{d['vlan']}",
                f"dhcp-range=set:{t},{d['start']},{d['end']},{ii.network.netmask},{d['lease']}h",
                f"dhcp-option=tag:{t},option:router,{ii.ip}"]
        out.append(f"dhcp-option=tag:{t},option:dns-server" + (f",{d['dns']}" if d.get("dns") else ""))
    return "\n".join(out) + "\n", n


def apply_dhcp(c):
    try:
        with open(DNSMASQ_PID) as f:
            pid = int(f.read().strip())
        log(f"$ kill {pid}  (restart DHCP)")
        if not SIM:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass
    conf, n = build_dnsmasq(c)
    with open(DNSMASQ_CONF, "w") as f:
        f.write(conf)
    if n == 0:
        return
    if not SIM and not shutil.which("dnsmasq"):
        log("WARNING: dnsmasq is not installed - DHCP server not started")
        return
    time.sleep(0.3)
    sh(["dnsmasq", "--conf-file=" + DNSMASQ_CONF, "--pid-file=" + DNSMASQ_PID], ignore=True)


def apply_cfg(c):
    prev = load_applied()
    log(f"=== apply ({'SIMULATION' if SIM else 'LIVE'}) ===")
    mirror_dest = c["mirror"]["dest"] if c["mirror"]["enabled"] else 0
    sh(["ip", "link", "add", "name", BR, "type", "bridge", "vlan_filtering", "1", "vlan_default_pvid", "0"], ignore=True)
    sh(["ip", "link", "set", BR, "type", "bridge", "vlan_filtering", "1", "stp_state", "1" if c["stp"] else "0"], ignore=True)
    sh(["ip", "link", "set", BR, "up"])
    new_if = [port_iface(p) for p in c["ports"]]
    for old in prev.get("ifaces", []):
        sh(["tc", "qdisc", "del", "dev", old, "clsact"], ignore=True)
        if old not in new_if:
            sh(["ip", "link", "set", old, "nomaster"], ignore=True)
            if old.startswith("otsw-p"): sh(["ip", "link", "del", old], ignore=True)
    for p in c["ports"]:
        i = port_iface(p)
        if p["kind"] == "virtual": sh(["ip", "tuntap", "add", "dev", i, "mode", "tap"], ignore=True)
        else:
            sh(["nmcli", "device", "set", i, "managed", "no"], ignore=True)
            sh(["ip", "addr", "flush", "dev", i], ignore=True)
        if p["id"] == mirror_dest:
            sh(["ip", "link", "set", i, "nomaster"], ignore=True)   # monitor port: not part of the switching fabric
            sh(["ip", "link", "set", i, "up" if p["admin"] else "down"])
            continue
        sh(["ip", "link", "set", i, "master", BR])
        for v in current_vids(i): sh(["bridge", "vlan", "del", "vid", str(v), "dev", i], ignore=True)
        if p["mode"] == "access":
            sh(["bridge", "vlan", "add", "vid", str(p["vlan"]), "dev", i, "pvid", "untagged"])
        else:
            sh(["bridge", "vlan", "add", "vid", str(p["native"]), "dev", i, "pvid", "untagged"])
            for a in p["allowed"]:
                if a != p["native"]: sh(["bridge", "vlan", "add", "vid", str(a), "dev", i])
        sh(["ip", "link", "set", i, "up" if p["admin"] else "down"])
    if mirror_dest:
        byid = {p["id"]: port_iface(p) for p in c["ports"]}
        for s in c["mirror"]["sources"]:
            src, dst = byid[s], byid[mirror_dest]
            sh(["tc", "qdisc", "add", "dev", src, "clsact"], ignore=True)
            for d in ("ingress", "egress"):
                sh(["tc", "filter", "add", "dev", src, d, "matchall", "action", "mirred", "egress", "mirror", "dev", dst], ignore=True)
    new_sv = [f"vlan{s['vlan']}" for s in c["svis"]]
    for old in prev.get("svis", []):
        if old not in new_sv: sh(["ip", "link", "del", old], ignore=True)
    for s in c["svis"]:
        n = f"vlan{s['vlan']}"
        sh(["ip", "link", "add", "link", BR, "name", n, "type", "vlan", "id", str(s["vlan"])], ignore=True)
        sh(["bridge", "vlan", "add", "vid", str(s["vlan"]), "dev", BR, "self"], ignore=True)
        sh(["ip", "addr", "flush", "dev", n])
        sh(["ip", "addr", "add", s["ip"], "dev", n])
        sh(["ip", "link", "set", n, "up" if s["enabled"] else "down"])
    sh(["sysctl", "-w", f"net.ipv4.ip_forward={1 if c['routing'] else 0}"])
    for r in prev.get("routes", []): sh(["ip", "route", "del"] + r.split(), ignore=True)
    routes = []
    for r in c["routes"]:
        d = "0.0.0.0/0" if r["dest"].strip() == "default" else r["dest"].strip()
        sh(["ip", "route", "replace", d, "via", r["via"].strip()], ignore=True)
        routes.append(f"{d} via {r['via'].strip()}")
    sh(["nft", "-f", "-"], stdin=build_nft(c))
    apply_dhcp(c)
    with open(APPLIED_FILE, "w") as f:
        json.dump({"hash": chash(c), "ifaces": new_if, "svis": new_sv, "routes": routes}, f)
    log("=== apply done ===")


# ---------------------------------------------------------------- status
def read_leases():
    out = []
    try:
        with open(LEASES) as f:
            for ln in f:
                p = ln.split()
                if len(p) >= 4:
                    out.append({"expires": int(p[0]), "mac": p[1], "ip": p[2], "host": "" if p[3] == "*" else p[3]})
    except Exception:
        pass
    if SIM:
        out = [{"expires": int(time.time()) + 3600, "mac": "00:1d:9c:aa:01:10", "ip": "192.168.10.101", "host": "plc-1"}]
    return out


def status():
    c = load_cfg()
    ap = load_applied()
    live, fdb = {}, []
    applied = ap.get("hash") == chash(c)
    for p in c["ports"]:
        i = port_iface(p)
        if SIM:
            live[p["id"]] = {"link": bool(p["admin"] and applied and p["id"] % 3 != 0), "rx": 0, "tx": 0}
        else:
            live[p["id"]] = {"link": read_stat(i, "carrier") == "1" and p["admin"],
                             "rx": int(read_stat(i, "statistics/rx_bytes") or 0),
                             "tx": int(read_stat(i, "statistics/tx_bytes") or 0)}
    if SIM:
        fdb = [{"mac": "00:1d:9c:aa:01:10", "port": 1, "vlan": 10}, {"mac": "00:0c:29:5e:77:21", "port": 2, "vlan": 20}]
    else:
        try:
            m = {port_iface(p): p["id"] for p in c["ports"]}
            for d in json.loads(quiet(["bridge", "-j", "fdb", "show", "br", BR]) or "[]"):
                if d.get("ifname") in m and d.get("state") != "permanent":
                    fdb.append({"mac": d["mac"], "port": m[d["ifname"]], "vlan": d.get("vlan", "-")})
        except Exception:
            pass
    return {"ports": live, "fdb": fdb, "leases": read_leases(), "pending": not applied, "t": time.time()}


# ---------------------------------------------------------------- http
class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ct="application/json"):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def authed(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                u, _, p = base64.b64decode(h[6:]).decode().partition(":")
                if auth_ok(u, p):
                    return True
            except Exception:
                pass
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="OT Virtual Switch"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def do_GET(self):
        if self.path == "/api/ident":   # open: lets the Finder tool discover switches on the LAN
            return self.send(200, {"app": "otsw", "name": load_cfg()["name"], "sim": SIM, "version": VERSION})
        if not self.authed(): return
        if self.path == "/":
            with open(os.path.join(BASE, "index.html"), "rb") as f:
                return self.send(200, f.read(), "text/html; charset=utf-8")
        if self.path == "/api/config": return self.send(200, load_cfg())
        if self.path == "/api/meta":
            return self.send(200, {"sim": SIM, "nics": list_nics(), "version": VERSION, "default_pw": default_pw_in_use()})
        if self.path == "/api/status": return self.send(200, status())
        if self.path == "/api/log": return self.send(200, {"log": list(LOG)})
        self.send(404, {"error": "not found"})

    def do_POST(self):
        if not self.authed(): return
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            with LOCK:
                if self.path == "/api/config":
                    save_cfg(validate(body))
                    return self.send(200, {"ok": True})
                if self.path == "/api/apply":
                    c = validate(load_cfg()); apply_cfg(c)
                    return self.send(200, {"ok": True})
                if self.path == "/api/reset":
                    save_cfg(default_config())
                    return self.send(200, {"ok": True})
                if self.path == "/api/password":
                    set_password(str(body.get("password", "")))
                    return self.send(200, {"ok": True})
                if self.path == "/api/system":
                    act = body.get("action")
                    if act not in ("reboot", "poweroff"): raise ValueError("bad action")
                    log(f"System {act} requested")
                    if not SIM:
                        threading.Timer(1.5, lambda: subprocess.run(["systemctl", act])).start()
                    return self.send(200, {"ok": True})
            self.send(404, {"error": "not found"})
        except Exception as ex:
            log("ERROR " + str(ex))
            self.send(400, {"error": str(ex)})


def boot_apply():
    time.sleep(2)
    try:
        with LOCK:
            apply_cfg(validate(load_cfg()))
    except Exception as ex:
        log("Boot apply failed: " + str(ex))


def main():
    port = int(os.environ.get("OTSW_PORT", "8080"))
    bind = os.environ.get("OTSW_BIND", "0.0.0.0")
    load_cfg()
    print(f"OT Virtual Switch {VERSION} on http://{bind}:{port}  mode={'SIMULATION' if SIM else 'LIVE'}  data={DATA}", flush=True)
    if not SIM and os.environ.get("OTSW_NO_BOOT_APPLY") != "1":
        threading.Thread(target=boot_apply, daemon=True).start()
    try:
        ThreadingHTTPServer((bind, port), H).serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
