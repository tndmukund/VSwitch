#!/usr/bin/env python3
"""OT Virtual Switch - GUI-managed L2/L3 switch on top of the Linux bridge.

Python 3 standard library only. Run as root on Linux (appliance image, Raspberry Pi,
laptop, VM) to really configure the kernel. Anywhere else (or without root) it runs in
SIMULATION mode: the GUI works fully, commands are only logged.
"""
import base64, collections, copy, hashlib, hmac, ipaddress, json, math, os, re, secrets, shutil, signal, subprocess, sys, threading, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

VERSION = "1.2.0"
BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
IS_LINUX_ROOT = sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0 and bool(shutil.which("ip"))
SIM = os.environ.get("OTSW_SIM") == "1" or not IS_LINUX_ROOT
DATA = os.environ.get("OTSW_DATA") or ("/var/lib/otsw" if IS_LINUX_ROOT and not SIM else os.path.dirname(os.path.abspath(__file__)))
os.makedirs(DATA, exist_ok=True)
CFG_FILE = os.environ.get("OTSW_CONFIG", os.path.join(DATA, "config.json"))
APPLIED_FILE = os.path.join(DATA, "applied.json")
AUTH_FILE = os.path.join(DATA, "auth.json")
DNSMASQ_CONF = os.path.join(DATA, "dnsmasq.conf")
DNSMASQ_PID = os.path.join(DATA, "dnsmasq.pid")
LEASES = os.path.join(DATA, "dnsmasq.leases")
FRR_CONF = "/etc/frr/frr.conf"
SNMP_CONF = "/etc/snmp/snmpd.conf"
SNMP_USERS = "/var/lib/snmp/snmpd.conf"
BR = "br0"
USER = os.environ.get("OTSW_USER", "admin")
DEFAULT_PASSWORD = os.environ.get("OTSW_PASSWORD", "admin")

LOCK = threading.Lock()
LOG = collections.deque(maxlen=600)
HISTORY = collections.deque(maxlen=360)       # 30 min at 5 s
IFRE = re.compile(r"^[A-Za-z0-9_.\-]{1,15}$")
NAMERE = re.compile(r"^[\w .\-]{1,32}$")
MACRE = re.compile(r"^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$")
HOSTRE = re.compile(r"^[A-Za-z0-9.\-]{1,100}$")


def log(msg):
    LOG.append(time.strftime("%H:%M:%S ") + msg)


# ---------------------------------------------------------------- config
PORT_DEFAULTS = {
    "speed": "auto", "duplex": "auto", "mtu": 1500, "isolated": False, "channel": 0,
    "stp_cost": 0, "bpdu_guard": False, "root_guard": False,
    "sec": False, "sec_macs": "", "storm_bc": 0, "storm_mc": 0, "dhcp_trusted": True,
    "rate_in": 0, "rate_out": 0, "lldp": True,
}

TOP_DEFAULTS = {
    "stp": False,
    "stp_opts": {"priority": 32768, "hello": 2, "max_age": 20, "forward_delay": 15},
    "ageing": 300,
    "igmp": {"snooping": False, "querier": False},
    "dhcp_snooping": False,
    "lldp": {"enabled": True},
    "lags": [], "static_macs": [], "dhcp": [], "dhcp_relay": [], "routes": [], "svis": [],
    "mirror": {"enabled": False, "sources": [], "dest": 0},
    "dyn": {
        "ospf": {"enabled": False, "router_id": "", "networks": [], "redistribute_connected": True, "redistribute_static": False},
        "rip": {"enabled": False, "networks": [], "redistribute_connected": True},
        "bgp": {"enabled": False, "asn": 65001, "router_id": "", "neighbors": [], "networks": [], "redistribute_connected": False},
        "vrrp": [],
    },
    "snmp": {"enabled": False, "community": "public", "source": "", "v3_user": "", "v3_auth": "", "v3_priv": "",
             "location": "", "contact": "", "trap_host": "", "trap_community": "public"},
    "syslog": {"enabled": False, "host": "", "port": 514, "proto": "udp"},
    "ntp": {"servers": "", "timezone": "UTC"},
    "mgmt": {"mode": "dhcp", "ip": "", "gw": "", "dns": ""},
}


def default_config():
    c = {
        "name": "OT-SW1",
        "routing": True,
        "ports": [
            dict({"id": i, "label": f"Gi1/{i}", "kind": "virtual", "iface": "", "mode": "access",
                  "vlan": 1, "native": 1, "allowed": [], "admin": True, "desc": ""}, **copy.deepcopy(PORT_DEFAULTS))
            for i in range(1, 9)
        ],
        "vlans": [{"id": 1, "name": "default"}, {"id": 10, "name": "PLC"},
                  {"id": 20, "name": "HMI"}, {"id": 99, "name": "MGMT"}],
        "firewall": {"default_forward": "drop", "rules": [
            {"src": "20", "dst": "10", "proto": "tcp", "port": "44818", "action": "accept",
             "comment": "HMI to PLC (EtherNet/IP)"}],
            "nat": {"enabled": False, "wan": "eth0"}},
    }
    c.update(copy.deepcopy(TOP_DEFAULTS))
    c["svis"] = [{"vlan": 10, "ip": "192.168.10.1/24", "enabled": True},
                 {"vlan": 20, "ip": "192.168.20.1/24", "enabled": True}]
    return c


def merge_defaults(dst, src):
    for k, v in src.items():
        if k not in dst:
            dst[k] = copy.deepcopy(v)
        elif isinstance(v, dict) and isinstance(dst[k], dict):
            merge_defaults(dst[k], v)


def upgrade(c):
    merge_defaults(c, TOP_DEFAULTS)
    c.setdefault("firewall", {}).setdefault("nat", {"enabled": False, "wan": "eth0"})
    for p in c.get("ports", []):
        if isinstance(p, dict):
            merge_defaults(p, PORT_DEFAULTS)
    return c


def load_cfg():
    try:
        with open(CFG_FILE) as f:
            return upgrade(json.load(f))
    except Exception:
        c = default_config()
        save_cfg(c)
        return c


def save_cfg(c):
    tmp = CFG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(c, f, indent=2)
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.replace(tmp, CFG_FILE)


def chash(c):
    return hashlib.sha256(json.dumps(c, sort_keys=True).encode()).hexdigest()


def load_applied():
    try:
        with open(APPLIED_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def port_iface(p):
    return f"otsw-p{p['id']}" if p["kind"] == "virtual" else p["iface"]


def bond_iface(lid):
    return f"otsw-bond{lid}"


def macs_of(s):
    return [x.lower() for x in re.split(r"[,\s]+", str(s or "").strip()) if x]


# ---------------------------------------------------------------- auth
def pw_hash(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 120000).hex()


def auth_ok(user, pw):
    try:
        with open(AUTH_FILE) as f:
            a = json.load(f)
        return hmac.compare_digest(user, a["user"]) and hmac.compare_digest(pw_hash(pw, a["salt"]), a["hash"])
    except FileNotFoundError:
        return hmac.compare_digest(user, USER) and hmac.compare_digest(pw, DEFAULT_PASSWORD)
    except Exception:
        return False


def default_pw_in_use():
    return not os.path.exists(AUTH_FILE) and DEFAULT_PASSWORD == "admin"


def set_password(new):
    if len(new) < 6:
        raise ValueError("Password must be at least 6 characters")
    salt = secrets.token_hex(16)
    tmp = AUTH_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"user": USER, "salt": salt, "hash": pw_hash(new, salt)}, f)
    os.chmod(tmp, 0o600)
    os.replace(tmp, AUTH_FILE)


# ---------------------------------------------------------------- system helpers
def sh(args, stdin=None, ignore=False):
    log("$ " + " ".join(args) + ("   <script>" if stdin else ""))
    if SIM:
        return ""
    try:
        r = subprocess.run(args, input=stdin, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        if ignore:
            return ""
        raise RuntimeError(f"'{args[0]}' is not installed on this device")
    except subprocess.TimeoutExpired:
        if ignore:
            return ""
        raise RuntimeError(f"{' '.join(args)} timed out")
    if r.returncode and not ignore:
        raise RuntimeError(f"{' '.join(args)} -> {r.stderr.strip() or r.stdout.strip()}")
    return r.stdout


def quiet(args, timeout=15):
    if SIM:
        return ""
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except Exception:
        return ""
    return r.stdout if r.returncode == 0 else ""


def write_file(path, text, mode=0o644):
    log(f"write {path}")
    if SIM:
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)
    os.chmod(path, mode)


def remove_file(path):
    if os.path.exists(path):
        log(f"remove {path}")
        if not SIM:
            os.remove(path)


def default_route_iface():
    if SIM:
        return ""
    try:
        for r in json.loads(quiet(["ip", "-j", "route", "show", "default"]) or "[]"):
            return r.get("dev", "")
    except Exception:
        pass
    return ""


def mgmt_iface():
    try:
        with open("/etc/systemd/network/10-otsw-mgmt.network") as f:
            m = re.search(r"^Name=(\S+)", f.read(), re.M)
            if m:
                return m.group(1)
    except Exception:
        pass
    return default_route_iface()


def read_stat(i, name):
    try:
        with open(f"/sys/class/net/{i}/{name}") as f:
            return f.read().strip()
    except Exception:
        return ""


def list_nics():
    mgmt = default_route_iface()
    if SIM:
        return [{"name": n, "mac": m, "speed": s, "state": st, "mgmt": n == "eth0"} for n, m, s, st in
                [("eth0", "00:0c:29:aa:00:01", 1000, "up"), ("eth1", "00:0c:29:aa:00:02", 1000, "up"),
                 ("eth2", "00:0c:29:aa:00:03", 1000, "down"), ("enx001122334455", "00:11:22:33:44:55", 100, "up")]]
    out = []
    try:
        for n in sorted(os.listdir("/sys/class/net")):
            if n in ("lo", BR) or n.startswith(("veth", "docker", "vlan", "otsw-", "tap", "virbr", "br-", "wl", "ww", "tun", "bond")):
                continue
            if not os.path.exists(f"/sys/class/net/{n}/device") and not n.startswith("eth"):
                continue
            sp = read_stat(n, "speed")
            out.append({"name": n, "mac": read_stat(n, "address"),
                        "speed": int(sp) if sp.lstrip("-").isdigit() and int(sp) > 0 else 0,
                        "state": read_stat(n, "operstate") or "unknown", "mgmt": n == mgmt})
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- validation
def _net(s):
    return ipaddress.ip_network(s, strict=False)


def validate(c):
    e = []
    if not isinstance(c, dict):
        raise ValueError("bad config")
    c = upgrade(c)
    if not NAMERE.match(str(c.get("name", ""))):
        e.append("Switch name: 1-32 letters/digits/space/-/_")
    vids = []
    for v in c.get("vlans", []):
        try:
            i = int(v["id"])
        except Exception:
            e.append("VLAN id must be a number"); continue
        if not 1 <= i <= 4094: e.append(f"VLAN {i}: id must be 1-4094")
        if i in vids: e.append(f"VLAN {i}: duplicate")
        if not NAMERE.match(str(v.get("name", ""))): e.append(f"VLAN {i}: invalid name")
        vids.append(i)
    if 1 not in vids: e.append("VLAN 1 must exist")

    # port-channels
    lag_ids = set()
    for l in c["lags"]:
        lid = l.get("id")
        if not isinstance(lid, int) or not 1 <= lid <= 8 or lid in lag_ids: e.append(f"Port-channel {lid}: id must be unique 1-8"); continue
        lag_ids.add(lid)
        if not NAMERE.match(str(l.get("name", ""))): e.append(f"Port-channel {lid}: invalid name")
        if l.get("mode") not in ("802.3ad", "active-backup", "balance-xor"): e.append(f"Port-channel {lid}: bad mode")
        if l.get("rate") not in ("slow", "fast"): e.append(f"Port-channel {lid}: bad LACP rate")
        if l.get("hash") not in ("layer2", "layer2+3", "layer3+4"): e.append(f"Port-channel {lid}: bad hash")
        if l.get("pmode") not in ("access", "trunk"): e.append(f"Port-channel {lid}: bad mode")
        if l.get("vlan") not in vids: e.append(f"Port-channel {lid}: VLAN {l.get('vlan')} does not exist")
        if l.get("pmode") == "trunk":
            if l.get("native") not in vids: e.append(f"Port-channel {lid}: native VLAN does not exist")
            for a in l.get("allowed", []):
                if a not in vids: e.append(f"Port-channel {lid}: allowed VLAN {a} does not exist")

    ports = c.get("ports", [])
    if not 1 <= len(ports) <= 48: e.append("Port count must be 1-48")
    ids, ifs = set(), set()
    mgmt = default_route_iface()
    for p in ports:
        pid = p.get("id")
        if not isinstance(pid, int) or pid < 1 or pid in ids: e.append(f"Port id {pid}: invalid/duplicate"); continue
        ids.add(pid)
        P = f"Port {pid}"
        if p.get("kind") not in ("virtual", "physical"): e.append(f"{P}: bad type")
        if p.get("mode") not in ("access", "trunk"): e.append(f"{P}: bad mode")
        if not re.match(r"^[\w ./\-]{1,16}$", str(p.get("label", ""))): e.append(f"{P}: invalid label")
        if p.get("kind") == "physical":
            n = p.get("iface", "")
            if not IFRE.match(n): e.append(f"{P}: choose a network adapter")
            elif n in ifs: e.append(f"{P}: adapter {n} already used")
            elif n == mgmt: e.append(f"{P}: {n} carries this device's management connection - using it would lock you out")
            ifs.add(n)
        if p.get("vlan") not in vids: e.append(f"{P}: VLAN {p.get('vlan')} does not exist")
        if p.get("mode") == "trunk":
            if p.get("native") not in vids: e.append(f"{P}: native VLAN does not exist")
            for a in p.get("allowed", []):
                if a not in vids: e.append(f"{P}: allowed VLAN {a} does not exist")
        if p["speed"] not in ("auto", 10, 100, 1000, 2500, 10000): e.append(f"{P}: bad speed")
        if p["duplex"] not in ("auto", "full", "half"): e.append(f"{P}: bad duplex")
        for k, lo, hi in (("mtu", 576, 9216), ("stp_cost", 0, 200000000), ("storm_bc", 0, 10000000), ("storm_mc", 0, 10000000),
                          ("rate_in", 0, 100000000), ("rate_out", 0, 100000000)):
            if not (isinstance(p[k], int) and not isinstance(p[k], bool) and lo <= p[k] <= hi): e.append(f"{P}: {k} must be {lo}-{hi}")
        if p["channel"] != 0 and p["channel"] not in lag_ids: e.append(f"{P}: port-channel {p['channel']} does not exist")
        bad = [m for m in macs_of(p["sec_macs"]) if not MACRE.match(m)]
        if bad: e.append(f"{P}: invalid MAC {bad[0]}")
        if p["sec"] and not macs_of(p["sec_macs"]): e.append(f"{P}: port security needs at least one allowed MAC")
    for lid in lag_ids:
        if not any(p.get("channel") == lid for p in ports): e.append(f"Port-channel {lid} has no member ports")

    svi_net = {}
    for s in c.get("svis", []):
        if s.get("vlan") not in vids: e.append(f"L3 interface: VLAN {s.get('vlan')} does not exist")
        if s.get("vlan") in svi_net: e.append(f"L3 interface: VLAN {s.get('vlan')} defined twice")
        try:
            ii = ipaddress.ip_interface(s.get("ip", ""))
            if ii.version != 4: raise ValueError
            svi_net[s.get("vlan")] = ii
        except Exception:
            svi_net[s.get("vlan")] = None
            e.append(f"VLAN {s.get('vlan')}: IP must look like 192.168.1.1/24")
    for r in c.get("routes", []):
        try:
            d = r["dest"].strip()
            ipaddress.ip_network("0.0.0.0/0" if d == "default" else d, strict=False)
            ipaddress.ip_address(r["via"].strip())
        except Exception:
            e.append(f"Route {r.get('dest')} via {r.get('via')}: invalid")
    seen = set()
    for d in c.get("dhcp", []):
        v = d.get("vlan")
        if v in seen: e.append(f"DHCP VLAN {v}: defined twice")
        seen.add(v)
        ii = svi_net.get(v)
        if ii is None:
            e.append(f"DHCP VLAN {v}: the VLAN needs an L3 interface with a valid IP first"); continue
        try:
            a, b = ipaddress.ip_address(d["start"]), ipaddress.ip_address(d["end"])
            if a not in ii.network or b not in ii.network or int(a) > int(b): raise ValueError
            if int(a) <= int(ii.ip) <= int(b): e.append(f"DHCP VLAN {v}: range must not include the gateway {ii.ip}")
        except Exception:
            e.append(f"DHCP VLAN {v}: start/end must be inside {ii.network} and start <= end")
        if not (isinstance(d.get("lease"), int) and 1 <= d["lease"] <= 720): e.append(f"DHCP VLAN {v}: lease 1-720 hours")
        if d.get("dns"):
            try: ipaddress.ip_address(d["dns"])
            except Exception: e.append(f"DHCP VLAN {v}: DNS server invalid")
    for d in c["dhcp_relay"]:
        v = d.get("vlan")
        if svi_net.get(v) is None: e.append(f"DHCP relay VLAN {v}: needs an L3 interface first")
        if v in seen: e.append(f"DHCP relay VLAN {v}: already has a DHCP server scope")
        try: ipaddress.ip_address(d.get("server", ""))
        except Exception: e.append(f"DHCP relay VLAN {v}: server address invalid")

    m = c["mirror"]
    if m.get("enabled"):
        if m.get("dest") not in ids: e.append("Mirror: choose a destination port")
        if not m.get("sources"): e.append("Mirror: choose at least one source port")
        for s in m.get("sources", []):
            if s not in ids: e.append(f"Mirror: source port {s} does not exist")
            if s == m.get("dest"): e.append("Mirror: destination cannot also be a source")
        dp = next((p for p in ports if p.get("id") == m.get("dest")), None)
        if dp and dp.get("channel"): e.append("Mirror: destination cannot be a port-channel member")

    st = c["stp_opts"]
    if st["priority"] not in range(0, 61441, 4096): e.append("STP: priority must be a multiple of 4096 (0-61440)")
    if not 1 <= st["hello"] <= 10: e.append("STP: hello time 1-10 s")
    if not 6 <= st["max_age"] <= 40: e.append("STP: max age 6-40 s")
    if not 4 <= st["forward_delay"] <= 30: e.append("STP: forward delay 4-30 s")
    if not (isinstance(c["ageing"], int) and 10 <= c["ageing"] <= 1000000): e.append("MAC ageing time must be 10-1000000 s")
    for sm in c["static_macs"]:
        if not MACRE.match(str(sm.get("mac", ""))): e.append(f"Static MAC {sm.get('mac')}: invalid")
        if sm.get("port") not in ids: e.append(f"Static MAC {sm.get('mac')}: port does not exist")
        if sm.get("vlan") not in vids: e.append(f"Static MAC {sm.get('mac')}: VLAN does not exist")

    dy = c["dyn"]
    o = dy["ospf"]
    if o["enabled"]:
        if o["router_id"]:
            try: ipaddress.IPv4Address(o["router_id"])
            except Exception: e.append("OSPF: router-id must be an IPv4 address")
        if not o["networks"]: e.append("OSPF: add at least one network")
        for n in o["networks"]:
            try: _net(n["net"])
            except Exception: e.append(f"OSPF network {n.get('net')}: invalid")
            if not re.match(r"^\d{1,10}(\.\d{1,3}){0,3}$", str(n.get("area", ""))): e.append(f"OSPF network {n.get('net')}: bad area")
    r = dy["rip"]
    if r["enabled"]:
        if not r["networks"]: e.append("RIP: add at least one network")
        for n in r["networks"]:
            try: _net(n["net"])
            except Exception: e.append(f"RIP network {n.get('net')}: invalid")
    b = dy["bgp"]
    if b["enabled"]:
        if not (isinstance(b["asn"], int) and 1 <= b["asn"] <= 4294967295): e.append("BGP: AS number invalid")
        if b["router_id"]:
            try: ipaddress.IPv4Address(b["router_id"])
            except Exception: e.append("BGP: router-id must be an IPv4 address")
        for n in b["neighbors"]:
            try: ipaddress.ip_address(n["ip"])
            except Exception: e.append(f"BGP neighbor {n.get('ip')}: invalid address")
            if not (isinstance(n.get("asn"), int) and 1 <= n["asn"] <= 4294967295): e.append(f"BGP neighbor {n.get('ip')}: remote AS invalid")
        for n in b["networks"]:
            try: _net(n["net"])
            except Exception: e.append(f"BGP network {n.get('net')}: invalid")
    vr = set()
    for v in dy["vrrp"]:
        ii = svi_net.get(v.get("vlan"))
        if ii is None: e.append(f"VRRP VLAN {v.get('vlan')}: needs an L3 interface first"); continue
        if not (isinstance(v.get("vrid"), int) and 1 <= v["vrid"] <= 255): e.append("VRRP: group id 1-255")
        if (v.get("vlan"), v.get("vrid")) in vr: e.append("VRRP: duplicate group")
        vr.add((v.get("vlan"), v.get("vrid")))
        try:
            if ipaddress.ip_address(v["ip"]) not in ii.network or ipaddress.ip_address(v["ip"]) == ii.ip:
                raise ValueError
        except Exception:
            e.append(f"VRRP VLAN {v.get('vlan')}: virtual IP must be a free address inside {ii.network}")
        if not (isinstance(v.get("priority"), int) and 1 <= v["priority"] <= 254): e.append("VRRP: priority 1-254")

    sn = c["snmp"]
    if sn["enabled"]:
        if not re.match(r"^[\w.\-@!#%]{1,32}$", str(sn["community"])) and not sn["v3_user"]: e.append("SNMP: community is 1-32 chars (no spaces)")
        if sn["community"] and not re.match(r"^[\w.\-@!#%]{1,32}$", str(sn["community"])): e.append("SNMP: community is 1-32 chars (no spaces)")
        if sn["source"]:
            try: _net(sn["source"])
            except Exception: e.append("SNMP: allowed source must be like 192.168.1.0/24")
        if sn["v3_user"]:
            if not re.match(r"^\w{1,32}$", sn["v3_user"]): e.append("SNMPv3: user name 1-32 letters/digits")
            if len(sn["v3_auth"]) < 8 or len(sn["v3_priv"]) < 8: e.append("SNMPv3: auth and privacy passwords need at least 8 characters")
            if re.search(r'[\s"\']', sn["v3_auth"] + sn["v3_priv"]): e.append("SNMPv3: passwords cannot contain spaces or quotes")
        for k in ("location", "contact"):
            if not re.match(r"^[\w .,@\-/]{0,64}$", str(sn[k])): e.append(f"SNMP: {k} has invalid characters")
        if sn["trap_host"] and not HOSTRE.match(sn["trap_host"]): e.append("SNMP: trap host invalid")
        if not re.match(r"^[\w.\-@!#%]{1,32}$", str(sn["trap_community"])): e.append("SNMP: trap community invalid")
    sl = c["syslog"]
    if sl["enabled"]:
        if not HOSTRE.match(str(sl["host"])): e.append("Syslog: server address invalid")
        if not (isinstance(sl["port"], int) and 1 <= sl["port"] <= 65535): e.append("Syslog: port 1-65535")
        if sl["proto"] not in ("udp", "tcp"): e.append("Syslog: protocol udp/tcp")
    nt = c["ntp"]
    if not re.match(r"^[\w.\- ]{0,200}$", str(nt["servers"])): e.append("NTP: servers invalid")
    if not re.match(r"^[A-Za-z0-9_+\-/]{1,40}$", str(nt["timezone"])): e.append("Time zone invalid (e.g. Asia/Kolkata)")
    mg = c["mgmt"]
    if mg["mode"] not in ("dhcp", "static"): e.append("Management: mode must be dhcp/static")
    if mg["mode"] == "static":
        try:
            ii = ipaddress.ip_interface(mg["ip"]); assert ii.version == 4
            if mg["gw"] and ipaddress.ip_address(mg["gw"]) not in ii.network: e.append("Management: gateway is outside the subnet")
        except Exception:
            e.append("Management: static IP must look like 192.168.1.50/24 and gateway must be an IPv4 address")
        if mg["dns"]:
            for d in re.split(r"[ ,]+", mg["dns"].strip()):
                try: ipaddress.ip_address(d)
                except Exception: e.append("Management: DNS invalid")
    fw = c.get("firewall", {})
    if fw.get("default_forward") not in ("accept", "drop"): e.append("Firewall: default policy must be accept/drop")
    for n, r in enumerate(fw.get("rules", []), 1):
        for k in ("src", "dst"):
            if r.get(k) not in ("any", "wan") and not (str(r.get(k, "")).isdigit() and int(r[k]) in vids):
                e.append(f"Rule {n}: bad {k}")
        if r.get("proto") not in ("any", "tcp", "udp", "icmp"): e.append(f"Rule {n}: bad protocol")
        if r.get("port") and not re.match(r"^\d{1,5}(-\d{1,5})?$", str(r["port"])): e.append(f"Rule {n}: bad port")
        if r.get("action") not in ("accept", "drop"): e.append(f"Rule {n}: bad action")
    nat = fw.get("nat", {})
    if nat.get("enabled") and not IFRE.match(str(nat.get("wan", ""))): e.append("NAT: invalid WAN adapter")
    if e:
        raise ValueError("; ".join(e))
    return c


# ---------------------------------------------------------------- generated config text
def build_nft(c):
    fw = c["firewall"]
    wan = fw.get("nat", {}).get("wan", "")

    def ifn(x):
        return wan if x == "wan" else f"vlan{x}"
    lines = ["table inet otsw", "delete table inet otsw", "table inet otsw {",
             "  chain forward {", f"    type filter hook forward priority 0; policy {fw['default_forward']};",
             "    ct state established,related accept"]
    for r in fw["rules"]:
        m = ""
        if r["src"] != "any": m += f' iifname "{ifn(r["src"])}"'
        if r["dst"] != "any": m += f' oifname "{ifn(r["dst"])}"'
        if r["proto"] == "icmp": m += " meta l4proto { icmp, ipv6-icmp }"
        elif r["proto"] in ("tcp", "udp"):
            m += f" {r['proto']} dport {r['port']}" if r.get("port") else f" meta l4proto {r['proto']}"
        cm = re.sub(r'[^\w .\-]', "", r.get("comment", ""))[:60]
        lines.append(f'   {m} {r["action"]}' + (f' comment "{cm}"' if cm else ""))
    lines += ["  }", "}"]
    lines += ["table ip otsw_nat", "delete table ip otsw_nat"]
    if fw.get("nat", {}).get("enabled"):
        lines += ["table ip otsw_nat {", "  chain post {", "    type nat hook postrouting priority 100;",
                  f'    oifname "{wan}" masquerade', "  }", "}"]
    return "\n".join(lines) + "\n"


def build_nft_bridge(c):
    """Port security, storm control, DHCP snooping (bridge-level filters on each port)."""
    rules = []
    for p in c["ports"]:
        if p["channel"]:
            continue
        i = port_iface(p)
        if c["dhcp_snooping"] and not p["dhcp_trusted"]:
            rules.append(f'iifname "{i}" ether type ip ip protocol udp udp sport 67 drop comment "dhcp-snooping"')
        if p["sec"]:
            rules.append(f'iifname "{i}" ether saddr != {{ {", ".join(macs_of(p["sec_macs"]))} }} drop comment "port-security"')
        if p["storm_bc"]:
            rules.append(f'iifname "{i}" meta pkttype broadcast limit rate over {p["storm_bc"]}/second drop comment "storm-bc"')
        if p["storm_mc"]:
            rules.append(f'iifname "{i}" meta pkttype multicast limit rate over {p["storm_mc"]}/second drop comment "storm-mc"')
    out = ["table bridge otsw_br", "delete table bridge otsw_br"]
    if rules:
        out += ["table bridge otsw_br {", "  chain pre {", "    type filter hook prerouting priority -200; policy accept;"]
        out += ["    " + r for r in rules] + ["  }", "}"]
    return "\n".join(out) + "\n"


def build_dnsmasq(c):
    ips = {s["vlan"]: ipaddress.ip_interface(s["ip"]) for s in c["svis"] if s["enabled"]}
    out = ["port=0", "bind-dynamic", "except-interface=lo", f"dhcp-leasefile={LEASES}", "dhcp-authoritative", "log-dhcp"]
    n = 0
    for d in c["dhcp"]:
        ii = ips.get(d["vlan"])
        if not ii:
            continue
        t = f"v{d['vlan']}"
        n += 1
        out += [f"interface=vlan{d['vlan']}",
                f"dhcp-range=set:{t},{d['start']},{d['end']},{ii.network.netmask},{d['lease']}h",
                f"dhcp-option=tag:{t},option:router,{ii.ip}"]
        out.append(f"dhcp-option=tag:{t},option:dns-server" + (f",{d['dns']}" if d.get("dns") else ""))
    for r in c["dhcp_relay"]:
        ii = ips.get(r["vlan"])
        if ii:
            n += 1
            out += [f"interface=vlan{r['vlan']}", f"dhcp-relay={ii.ip},{r['server']},vlan{r['vlan']}"]
    return "\n".join(out) + "\n", n


def build_frr(c):
    dy = c["dyn"]
    svi = {s["vlan"]: s for s in c["svis"]}
    out = ["frr defaults traditional", "hostname otsw", "log syslog informational", "service integrated-vtysh-config", "!"]
    used = False
    o = dy["ospf"]
    if o["enabled"]:
        used = True
        out.append("router ospf")
        if o["router_id"]: out.append(f" ospf router-id {o['router_id']}")
        for n in o["networks"]: out.append(f" network {_net(n['net'])} area {n['area']}")
        if o["redistribute_connected"]: out.append(" redistribute connected")
        if o["redistribute_static"]: out.append(" redistribute static")
        out.append("!")
    r = dy["rip"]
    if r["enabled"]:
        used = True
        out += ["router rip", " version 2"]
        for n in r["networks"]: out.append(f" network {_net(n['net'])}")
        if r["redistribute_connected"]: out.append(" redistribute connected")
        out.append("!")
    b = dy["bgp"]
    if b["enabled"]:
        used = True
        out += [f"router bgp {b['asn']}", " no bgp ebgp-requires-policy"]
        if b["router_id"]: out.append(f" bgp router-id {b['router_id']}")
        for n in b["neighbors"]: out.append(f" neighbor {n['ip']} remote-as {n['asn']}")
        out.append(" address-family ipv4 unicast")
        for n in b["networks"]: out.append(f"  network {_net(n['net'])}")
        if b["redistribute_connected"]: out.append("  redistribute connected")
        for n in b["neighbors"]: out.append(f"  neighbor {n['ip']} activate")
        out += [" exit-address-family", "!"]
    for v in dy["vrrp"]:
        if v["vlan"] in svi:
            used = True
            out += [f"interface vlan{v['vlan']}", f" vrrp {v['vrid']} version 3", f" vrrp {v['vrid']} priority {v['priority']}",
                    f" vrrp {v['vrid']} ip {v['ip']}"]
            out.append(f" {'' if v.get('preempt', True) else 'no '}vrrp {v['vrid']} preempt")
            out.append("!")
    out.append("line vty\n!")
    return "\n".join(out) + "\n", used


def build_snmp(c):
    s = c["snmp"]
    o = ["agentaddress udp:161", f"sysName {c['name']}", "sysServices 76", "view all included .1"]
    if s["location"]: o.append(f"sysLocation {s['location']}")
    if s["contact"]: o.append(f"sysContact {s['contact']}")
    if s["community"]: o.append(f"rocommunity {s['community']} {s['source'] or 'default'} -V all")
    if s["v3_user"]: o.append(f"rouser {s['v3_user']} authPriv")
    if s["trap_host"]:
        o += [f"trap2sink {s['trap_host']} {s['trap_community']}", "authtrapenable 1"]
    return "\n".join(o) + "\n"


def current_vids(iface):
    out = quiet(["bridge", "-j", "vlan", "show", "dev", iface])
    try:
        return [v["vlan"] for d in json.loads(out or "[]") for v in d.get("vlans", [])]
    except Exception:
        return []


def svc(name, action):
    sh(["systemctl", action, name], ignore=True)


# ---------------------------------------------------------------- apply
def apply_dhcp(c):
    try:
        with open(DNSMASQ_PID) as f:
            pid = int(f.read().strip())
        log(f"$ kill {pid}  (restart DHCP)")
        if not SIM:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass
    conf, n = build_dnsmasq(c)
    with open(DNSMASQ_CONF, "w") as f:
        f.write(conf)
    if n == 0:
        return
    if not SIM and not shutil.which("dnsmasq"):
        log("WARNING: dnsmasq is not installed - DHCP server not started")
        return
    time.sleep(0.3)
    sh(["dnsmasq", "--conf-file=" + DNSMASQ_CONF, "--pid-file=" + DNSMASQ_PID], ignore=True)


def apply_services(c, prev):
    """Optional services: a failure here is logged but never undoes the switching config."""
    def step(name, fn):
        try:
            fn()
        except Exception as ex:
            log(f"WARNING {name}: {ex}")
    step("DHCP", lambda: apply_dhcp(c))

    def lldp():
        if c["lldp"]["enabled"]:
            pat = ",".join([port_iface(p) for p in c["ports"] if p["lldp"]]) or "none"
            svc("lldpd", "start")
            sh(["lldpcli", "configure", "system", "interface", "pattern", pat], ignore=True)
            sh(["lldpcli", "configure", "system", "description", f"OT Virtual Switch {c['name']}"], ignore=True)
            sh(["lldpcli", "configure", "system", "hostname", c["name"]], ignore=True)
        else:
            svc("lldpd", "stop")
    step("LLDP", lldp)

    def snmp():
        s = c["snmp"]
        if s["enabled"]:
            svc("snmpd", "stop")
            write_file(SNMP_CONF, build_snmp(c), 0o600)
            write_file(SNMP_USERS, (f'createUser {s["v3_user"]} SHA "{s["v3_auth"]}" AES "{s["v3_priv"]}"\n' if s["v3_user"] else ""), 0o600)
            svc("snmpd", "enable"); svc("snmpd", "start")
        else:
            svc("snmpd", "stop"); svc("snmpd", "disable")
    step("SNMP", snmp)

    def syslog():
        p = "/etc/rsyslog.d/90-otsw.conf"
        s = c["syslog"]
        if s["enabled"]:
            write_file(p, f"*.* {'@@' if s['proto'] == 'tcp' else '@'}{s['host']}:{s['port']}\n")
        else:
            remove_file(p)
        svc("rsyslog", "restart")
    step("Syslog", syslog)

    def ntp():
        n = c["ntp"]
        if n["servers"].strip():
            write_file("/etc/systemd/timesyncd.conf.d/otsw.conf", f"[Time]\nNTP={n['servers'].strip()}\n")
        else:
            remove_file("/etc/systemd/timesyncd.conf.d/otsw.conf")
        sh(["timedatectl", "set-timezone", n["timezone"]], ignore=True)
        svc("systemd-timesyncd", "restart")
    step("NTP", ntp)

    def frr():
        text, used = build_frr(c)
        if used or prev.get("frr_used"):
            if text != prev.get("frr_text") or not prev:
                write_file(FRR_CONF, text, 0o640)
                if not SIM and shutil.which("chown"):
                    subprocess.run(["chown", "frr:frr", FRR_CONF], capture_output=True)
                svc("frr", "restart")
    step("Routing protocols", frr)

    def mgmt():
        mg, f = c["mgmt"], "/etc/systemd/network/05-otsw-mgmt-user.network"
        nic = mgmt_iface()
        if mg["mode"] == "static" and (nic or SIM):
            body = f"[Match]\nName={nic or 'MGMT'}\n\n[Network]\nAddress={mg['ip']}\n"
            if mg["gw"]: body += f"Gateway={mg['gw']}\n"
            for d in re.split(r"[ ,]+", mg["dns"].strip()):
                if d: body += f"DNS={d}\n"
            write_file(f, body)
        else:
            remove_file(f)
        if prev.get("mgmt") != mg:
            sh(["networkctl", "reload"], ignore=True)
    step("Management IP", mgmt)


def apply_cfg(c):
    prev = load_applied()
    log(f"=== apply ({'SIMULATION' if SIM else 'LIVE'}) ===")
    mirror_dest = c["mirror"]["dest"] if c["mirror"]["enabled"] else 0
    st = c["stp_opts"]
    sh(["ip", "link", "add", "name", BR, "type", "bridge", "vlan_filtering", "1", "vlan_default_pvid", "0"], ignore=True)
    sh(["ip", "link", "set", BR, "type", "bridge", "vlan_filtering", "1", "stp_state", "1" if c["stp"] else "0",
        "priority", str(st["priority"]), "hello_time", str(st["hello"] * 100), "max_age", str(st["max_age"] * 100),
        "forward_delay", str(st["forward_delay"] * 100), "ageing_time", str(c["ageing"] * 100),
        "mcast_snooping", "1" if c["igmp"]["snooping"] else "0", "mcast_querier", "1" if c["igmp"]["querier"] else "0"], ignore=True)
    sh(["ip", "link", "set", BR, "up"])

    lags = {l["id"]: l for l in c["lags"]}
    new_if = [port_iface(p) for p in c["ports"]] + [bond_iface(i) for i in lags]
    old_lags = prev.get("lags", {})
    for old in prev.get("ifaces", []):
        sh(["tc", "qdisc", "del", "dev", old, "clsact"], ignore=True)
        if old not in new_if:
            sh(["ip", "link", "set", old, "nomaster"], ignore=True)
            if old.startswith(("otsw-p", "otsw-bond")): sh(["ip", "link", "del", old], ignore=True)

    # port-channels (bonds)
    for lid, l in lags.items():
        b = bond_iface(lid)
        sig = json.dumps({k: l[k] for k in ("mode", "rate", "hash")})
        if old_lags.get(str(lid)) != sig:
            sh(["ip", "link", "del", b], ignore=True)
        args = ["ip", "link", "add", b, "type", "bond", "mode", l["mode"], "miimon", "100"]
        if l["mode"] == "802.3ad": args += ["lacp_rate", l["rate"], "xmit_hash_policy", l["hash"]]
        elif l["mode"] == "balance-xor": args += ["xmit_hash_policy", l["hash"]]
        sh(args, ignore=True)
    bridge_ifs = []      # (iface, vlan-config dict, port) facing the bridge

    for p in c["ports"]:
        i = port_iface(p)
        if p["kind"] == "virtual": sh(["ip", "tuntap", "add", "dev", i, "mode", "tap"], ignore=True)
        else:
            sh(["nmcli", "device", "set", i, "managed", "no"], ignore=True)
            sh(["ip", "addr", "flush", "dev", i], ignore=True)
            if p["speed"] == "auto":
                sh(["ethtool", "-s", i, "autoneg", "on"], ignore=True)
            else:
                sh(["ethtool", "-s", i, "speed", str(p["speed"]), "duplex", p["duplex"] if p["duplex"] != "auto" else "full", "autoneg", "off"], ignore=True)
        sh(["ip", "link", "set", i, "mtu", str(p["mtu"])], ignore=True)
        if p["id"] == mirror_dest:
            sh(["ip", "link", "set", i, "nomaster"], ignore=True)   # monitor port: not part of the switching fabric
            sh(["ip", "link", "set", i, "up" if p["admin"] else "down"])
            continue
        if p["channel"]:
            b = bond_iface(p["channel"])
            sh(["ip", "link", "set", i, "nomaster"], ignore=True)
            sh(["ip", "link", "set", i, "down"], ignore=True)
            sh(["ip", "link", "set", i, "master", b])
            sh(["ip", "link", "set", i, "up" if p["admin"] else "down"])
            continue
        sh(["ip", "link", "set", i, "master", BR])
        bridge_ifs.append((i, p, p))
        sh(["ip", "link", "set", i, "up" if p["admin"] else "down"])
    for lid, l in lags.items():
        b = bond_iface(lid)
        sh(["ip", "link", "set", b, "master", BR])
        sh(["ip", "link", "set", b, "up"])
        bridge_ifs.append((b, l, None))

    for i, vc, p in bridge_ifs:
        for v in current_vids(i): sh(["bridge", "vlan", "del", "vid", str(v), "dev", i], ignore=True)
        mode = vc["mode"] if p else vc["pmode"]
        if mode == "access":
            sh(["bridge", "vlan", "add", "vid", str(vc["vlan"]), "dev", i, "pvid", "untagged"])
        else:
            sh(["bridge", "vlan", "add", "vid", str(vc["native"]), "dev", i, "pvid", "untagged"])
            for a in vc["allowed"]:
                if a != vc["native"]: sh(["bridge", "vlan", "add", "vid", str(a), "dev", i])
        if p:
            sh(["bridge", "link", "set", "dev", i, "guard", "on" if p["bpdu_guard"] else "off",
                "root_block", "on" if p["root_guard"] else "off", "isolated", "on" if p["isolated"] else "off"], ignore=True)
            if p["stp_cost"]:
                sh(["bridge", "link", "set", "dev", i, "cost", str(p["stp_cost"])], ignore=True)

    # mirror + per-port rate limits (tc clsact)
    byid = {p["id"]: port_iface(p) for p in c["ports"]}
    for p in c["ports"]:
        i = port_iface(p)
        ing, egr = [], []
        if mirror_dest and p["id"] in c["mirror"]["sources"]:
            m = ["action", "mirred", "egress", "mirror", "dev", byid[mirror_dest]]
            ing += m; egr += m
        if p["rate_in"]: ing += ["action", "police", "rate", f"{p['rate_in']}kbit", "burst", "256k", "conform-exceed", "drop"]
        if p["rate_out"]: egr += ["action", "police", "rate", f"{p['rate_out']}kbit", "burst", "256k", "conform-exceed", "drop"]
        if ing or egr:
            sh(["tc", "qdisc", "add", "dev", i, "clsact"], ignore=True)
            if ing: sh(["tc", "filter", "add", "dev", i, "ingress", "prio", "1", "matchall"] + ing, ignore=True)
            if egr: sh(["tc", "filter", "add", "dev", i, "egress", "prio", "1", "matchall"] + egr, ignore=True)

    new_sv = [f"vlan{s['vlan']}" for s in c["svis"]]
    for old in prev.get("svis", []):
        if old not in new_sv: sh(["ip", "link", "del", old], ignore=True)
    for s in c["svis"]:
        n = f"vlan{s['vlan']}"
        sh(["ip", "link", "add", "link", BR, "name", n, "type", "vlan", "id", str(s["vlan"])], ignore=True)
        sh(["bridge", "vlan", "add", "vid", str(s["vlan"]), "dev", BR, "self"], ignore=True)
        sh(["ip", "addr", "flush", "dev", n])
        sh(["ip", "addr", "add", s["ip"], "dev", n])
        sh(["ip", "link", "set", n, "up" if s["enabled"] else "down"])
    sh(["sysctl", "-w", f"net.ipv4.ip_forward={1 if c['routing'] else 0}"])
    for r in prev.get("routes", []): sh(["ip", "route", "del"] + r.split(), ignore=True)
    routes = []
    for r in c["routes"]:
        d = "0.0.0.0/0" if r["dest"].strip() == "default" else r["dest"].strip()
        sh(["ip", "route", "replace", d, "via", r["via"].strip()], ignore=True)
        routes.append(f"{d} via {r['via'].strip()}")

    # static MAC entries
    for sm in prev.get("static_macs", []):
        sh(["bridge", "fdb", "del", sm["mac"], "dev", sm["dev"], "master", "vlan", str(sm["vlan"])], ignore=True)
    statics = []
    for sm in c["static_macs"]:
        p = next(x for x in c["ports"] if x["id"] == sm["port"])
        dev = bond_iface(p["channel"]) if p["channel"] else port_iface(p)
        sh(["bridge", "fdb", "replace", sm["mac"], "dev", dev, "master", "static", "vlan", str(sm["vlan"])], ignore=True)
        statics.append({"mac": sm["mac"], "dev": dev, "vlan": sm["vlan"]})

    sh(["nft", "-f", "-"], stdin=build_nft(c))
    sh(["nft", "-f", "-"], stdin=build_nft_bridge(c), ignore=True)
    apply_services(c, prev)
    frr_text, frr_used = build_frr(c)
    with open(APPLIED_FILE, "w") as f:
        json.dump({"hash": chash(c), "ifaces": new_if, "svis": new_sv, "routes": routes, "static_macs": statics,
                   "lags": {str(i): json.dumps({k: l[k] for k in ("mode", "rate", "hash")}) for i, l in lags.items()},
                   "frr_text": frr_text, "frr_used": frr_used, "mgmt": c["mgmt"]}, f)
    log("=== apply done ===")


# ---------------------------------------------------------------- status / monitoring
def read_leases():
    out = []
    try:
        with open(LEASES) as f:
            for ln in f:
                p = ln.split()
                if len(p) >= 4:
                    out.append({"expires": int(p[0]), "mac": p[1], "ip": p[2], "host": "" if p[3] == "*" else p[3]})
    except Exception:
        pass
    if SIM:
        out = [{"expires": int(time.time()) + 3600, "mac": "00:1d:9c:aa:01:10", "ip": "192.168.10.101", "host": "plc-1"},
               {"expires": int(time.time()) + 3600, "mac": "00:0c:29:5e:77:21", "ip": "192.168.20.101", "host": "hmi-1"}]
    return out


def port_stats(c):
    live = {}
    for p in c["ports"]:
        i = port_iface(p)
        if SIM:
            ap = load_applied().get("hash") == chash(c)
            live[p["id"]] = {"link": bool(p["admin"] and ap and p["id"] % 3 != 0), "rx": 0, "tx": 0, "err": 0, "speed": 1000}
        else:
            sp = read_stat(i, "speed")
            live[p["id"]] = {"link": read_stat(i, "carrier") == "1" and p["admin"],
                             "rx": int(read_stat(i, "statistics/rx_bytes") or 0),
                             "tx": int(read_stat(i, "statistics/tx_bytes") or 0),
                             "err": sum(int(read_stat(i, f"statistics/{k}") or 0) for k in ("rx_errors", "tx_errors", "rx_dropped", "tx_dropped")),
                             "speed": int(sp) if sp.lstrip("-").isdigit() and int(sp) > 0 else 0}
    return live


def status():
    c = load_cfg()
    ap = load_applied()
    fdb = []
    if SIM:
        fdb = [{"mac": "00:1d:9c:aa:01:10", "port": 2, "vlan": 10}, {"mac": "00:0c:29:5e:77:21", "port": 3, "vlan": 20},
               {"mac": "b8:27:eb:11:22:33", "port": 5, "vlan": 20}]
    else:
        try:
            m = {port_iface(p): p["id"] for p in c["ports"]}
            for p in c["ports"]:
                if p["channel"]: m[bond_iface(p["channel"])] = p["id"]
            for d in json.loads(quiet(["bridge", "-j", "fdb", "show", "br", BR]) or "[]"):
                if d.get("ifname") in m and d.get("state") != "permanent" and "self" not in d.get("flags", []):
                    fdb.append({"mac": d["mac"], "port": m[d["ifname"]], "vlan": d.get("vlan", "-")})
        except Exception:
            pass
    return {"ports": port_stats(c), "fdb": fdb, "leases": read_leases(), "pending": ap.get("hash") != chash(c), "t": time.time()}


def lldp_neighbors(c):
    if SIM:
        return [{"iface": "otsw-p6", "name": "core-sw", "chassis": "aa:bb:cc:00:00:01", "port": "Gi0/24", "descr": "uplink", "mgmt": "192.168.1.2"}]
    out = quiet(["lldpcli", "-f", "json", "show", "neighbors"])
    try:
        j = json.loads(out)
    except Exception:
        return []
    ifs = j.get("lldp", {}).get("interface", [])
    if isinstance(ifs, dict):
        ifs = [{k: v} for k, v in ifs.items()]
    res = []
    for entry in ifs:
        for ifname, d in entry.items():
            ch, name, cid, mg = d.get("chassis", {}), "", "", ""
            if isinstance(ch, dict):
                if isinstance(ch.get("id"), dict) and "type" in ch["id"]:
                    cid, mg = ch["id"].get("value", ""), ch.get("mgmt-ip", "")
                else:
                    for k, v in ch.items():
                        if isinstance(v, dict):
                            name, cid, mg = k, v.get("id", {}).get("value", ""), v.get("mgmt-ip", "")
            pt = d.get("port", {})
            res.append({"iface": ifname, "name": name, "chassis": cid, "port": pt.get("id", {}).get("value", ""),
                        "descr": pt.get("descr", ""), "mgmt": mg[0] if isinstance(mg, list) and mg else (mg if isinstance(mg, str) else "")})
    return res


def net_info():
    c = load_cfg()
    arp = []
    if SIM:
        arp = [{"ip": "192.168.10.101", "mac": "00:1d:9c:aa:01:10", "dev": "vlan10"}, {"ip": "192.168.20.101", "mac": "00:0c:29:5e:77:21", "dev": "vlan20"}]
        routes = "192.168.10.0/24 dev vlan10 proto kernel scope link src 192.168.10.1\n192.168.20.0/24 dev vlan20 proto kernel scope link src 192.168.20.1"
        proto = {k: "(simulation - no output)" for k in ("ospf", "rip", "bgp", "vrrp")}
    else:
        try:
            for d in json.loads(quiet(["ip", "-j", "neigh", "show"]) or "[]"):
                if d.get("lladdr") and d.get("dev", "").startswith(("vlan", BR)):
                    arp.append({"ip": d["dst"], "mac": d["lladdr"], "dev": d["dev"]})
        except Exception:
            pass
        routes = quiet(["ip", "route", "show"])
        proto = {"ospf": quiet(["vtysh", "-c", "show ip ospf neighbor"]), "rip": quiet(["vtysh", "-c", "show ip rip"]),
                 "bgp": quiet(["vtysh", "-c", "show bgp summary"]), "vrrp": quiet(["vtysh", "-c", "show vrrp"])}
    return {"lldp": lldp_neighbors(c), "arp": arp, "routes": routes, "proto": proto}


def sampler():
    prev, tprev = None, None
    n = 0
    while True:
        time.sleep(5)
        try:
            c = load_cfg()
            now = time.time()
            if SIM:
                n += 1
                cur = {p["id"]: {"rx": 0, "tx": 0} for p in c["ports"]}
                rates = {str(p["id"]): [abs(math.sin(n / 7 + p["id"])) * 4e6 * (p["id"] % 3 != 0), abs(math.cos(n / 9 + p["id"])) * 2e6 * (p["id"] % 3 != 0)] for p in c["ports"]}
                HISTORY.append({"t": now, "r": rates})
                continue
            cur = {p["id"]: port_stats_one(p) for p in c["ports"]}
            if prev and now > tprev:
                dt = now - tprev
                rates = {str(i): [max(0, (cur[i][0] - prev.get(i, cur[i])[0]) * 8 / dt), max(0, (cur[i][1] - prev.get(i, cur[i])[1]) * 8 / dt)] for i in cur}
                HISTORY.append({"t": now, "r": rates})
            prev, tprev = cur, now
        except Exception:
            pass


def port_stats_one(p):
    i = port_iface(p)
    return (int(read_stat(i, "statistics/rx_bytes") or 0), int(read_stat(i, "statistics/tx_bytes") or 0))


# ---------------------------------------------------------------- http
class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ct="application/json"):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def authed(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                u, _, p = base64.b64decode(h[6:]).decode().partition(":")
                if auth_ok(u, p):
                    return True
            except Exception:
                pass
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="OT Virtual Switch"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def do_GET(self):
        if self.path == "/api/ident":   # open: lets the Finder tool discover switches on the LAN
            return self.send(200, {"app": "otsw", "name": load_cfg()["name"], "sim": SIM, "version": VERSION})
        if not self.authed(): return
        if self.path == "/":
            with open(os.path.join(BASE, "index.html"), "rb") as f:
                return self.send(200, f.read(), "text/html; charset=utf-8")
        if self.path == "/api/config": return self.send(200, load_cfg())
        if self.path == "/api/meta":
            return self.send(200, {"sim": SIM, "nics": list_nics(), "version": VERSION, "default_pw": default_pw_in_use()})
        if self.path == "/api/status": return self.send(200, status())
        if self.path == "/api/net": return self.send(200, net_info())
        if self.path == "/api/history": return self.send(200, {"h": list(HISTORY)})
        if self.path == "/api/log": return self.send(200, {"log": list(LOG)})
        self.send(404, {"error": "not found"})

    def do_POST(self):
        if not self.authed(): return
        try:
            n = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(n) or b"{}")
            with LOCK:
                if self.path == "/api/config":
                    save_cfg(validate(body))
                    return self.send(200, {"ok": True})
                if self.path == "/api/apply":
                    c = validate(load_cfg()); apply_cfg(c)
                    return self.send(200, {"ok": True})
                if self.path == "/api/reset":
                    save_cfg(default_config())
                    return self.send(200, {"ok": True})
                if self.path == "/api/password":
                    set_password(str(body.get("password", "")))
                    return self.send(200, {"ok": True})
                if self.path == "/api/system":
                    act = body.get("action")
                    if act not in ("reboot", "poweroff"): raise ValueError("bad action")
                    log(f"System {act} requested")
                    if not SIM:
                        threading.Timer(1.5, lambda: subprocess.run(["systemctl", act])).start()
                    return self.send(200, {"ok": True})
            self.send(404, {"error": "not found"})
        except Exception as ex:
            log("ERROR " + str(ex))
            self.send(400, {"error": str(ex)})


def boot_apply():
    time.sleep(2)
    try:
        with LOCK:
            apply_cfg(validate(load_cfg()))
    except Exception as ex:
        log("Boot apply failed: " + str(ex))


def main():
    port = int(os.environ.get("OTSW_PORT", "8080"))
    bind = os.environ.get("OTSW_BIND", "0.0.0.0")
    load_cfg()
    print(f"OT Virtual Switch {VERSION} on http://{bind}:{port}  mode={'SIMULATION' if SIM else 'LIVE'}  data={DATA}", flush=True)
    threading.Thread(target=sampler, daemon=True).start()
    if not SIM and os.environ.get("OTSW_NO_BOOT_APPLY") != "1":
        threading.Thread(target=boot_apply, daemon=True).start()
    try:
        ThreadingHTTPServer((bind, port), H).serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
