# OT Virtual Switch

A GUI-only managed **L2 + L3 switch, router, firewall, DHCP server and SPAN** for OT labs.
No commands: open the web page, click a port on the switch picture, configure.

**Layer 2:** VLANs, access/trunk, add/remove ports live, LACP/static port-channels, STP (+BPDU/root guard, path cost), LLDP,
IGMP snooping/querier, port security (allowed MACs), broadcast/multicast storm control, DHCP snooping, port isolation,
speed/duplex/MTU, static MACs, MAC ageing, per-port rate limits, port mirroring (SPAN).
**Layer 3:** SVIs/inter-VLAN routing, static routes, OSPF, RIP, BGP, VRRP (FRRouting), DHCP server and relay, firewall (default-deny), NAT.

**OT security (v1.3):** *Flows & microsegmentation* tab - the switch listens on every port, shows who talks to whom (zone to zone map), recognises OT protocols from the packets (Modbus/TCP, EtherNet/IP + CIP, S7comm, DNP3, IEC 60870-5-104, OPC UA, BACnet/IP, OMRON FINS, PROFINET, GOOSE/SV) and the commands used (read / write / control), flags writes, and turns what it learned into Allow / Block rules per device, protocol and port - between VLANs and inside a VLAN (lateral movement). Not included: blocking single commands inside an allowed connection (detect only).

**Modules and licensing (v1.4):** on first start the GUI asks *What should this device be?* - Virtual Switch, L3 Switch, Router, Firewall + VPN, OT Firewall, or Everything - and shows only the matching pages. Modules: Layer 2, Layer 3 (routing, NAT, DHCP), Dynamic routing (OSPF/RIP/BGP/VRRP), Firewall, OT security (flow discovery, microsegmentation), VPN server (WireGuard). Without a licence key a new appliance runs 30 days of evaluation with everything unlocked; after that only basic ports/VLANs/monitoring work until a key is entered. Keys are signed (Ed25519): the appliance contains only the public key.

**For the vendor (selling it):** run `python tools/otsw_licensor.py genkey` once (creates `vendor-private.key` - keep it secret, never ship it, back it up; it also puts the matching public key into `app/license.py`), then `python tools/otsw_licensor.py` opens a window to create a key per customer (modules, expiry date, optional lock to one appliance's Machine ID). The workflow also builds `OT-Switch-Licence-Generator.exe` (artifact `vendor-licensor-windows`, deliberately not part of the public release). The app is plain Python: for stronger protection against edited source, compile or obfuscate the build.
**Management:** SNMP v2c/v3 + traps, syslog, NTP/time zone, management IP, HTTP login, backup/restore.
**Visibility:** live connection diagram, traffic graphs (30 min), MAC/ARP/LLDP/routing tables, DHCP leases, vendor lookup from MAC (Rockwell, Siemens, ...).

## Which file do I need?  (Releases page -> latest release)
| I want to run it on...                      | Download                                   | How |
|---------------------------------------------|--------------------------------------------|-----|
| **VMware ESXi / Workstation / Fusion**      | `otsw-*-amd64.ova`                         | Import/Deploy OVF. 4 NICs: NIC1 = management, NIC2-4 = switch ports. |
| **A PC / laptop / mini-PC (bare metal)**    | `otsw-*-amd64.img.xz`                      | Flash to USB/SSD with balenaEtcher, boot from it. First NIC = management, others = ports. |
| **Raspberry Pi 3/4/5**                      | `otsw-*-raspberrypi-arm64.img.xz`          | Raspberry Pi Imager -> "Use custom" -> pick file. Built-in port = management, add USB-Ethernet adapters as ports. |
| **Ubuntu/Debian laptop (already installed)**| `ot-virtual-switch_*.deb`                  | Double-click -> Install. GUI at http://localhost:8080 |
| **Windows / Linux desktop (helper)**        | `OT-Switch-Tool.exe` / `OT-Switch-Tool-linux` | Finds the switch on your network and opens its GUI; also has a DEMO mode. |

Open the GUI at `http://<switch-ip>` (images; address is shown on the console screen) - login `admin` / `admin`,
then change the password under **System**. Console login (recovery only): `root`/`otsw` (PC/VM image), `otsw`/`otsw` (Pi).

## Important notes
* **ESXi / vSwitch:** on the port group(s) used by NIC2-4 set Promiscuous mode, MAC address changes and Forged transmits to **Accept**,
  and VLAN ID **4095** (trunk all VLANs). Otherwise the virtual switch will not pass traffic. Workstation: use bridged or custom VMnets, one per port.
* **Windows has no Linux bridge/VLAN/nftables.** The `.exe` therefore only finds switches / runs the demo; run the real switch in the OVA (VMware Workstation/Player, VirtualBox can import it too) or on a Pi/PC image.
* Virtual ports (`otsw-pN`) are tap interfaces for VMs/containers on the same host; physical ports use real adapters.
  The adapter holding the management connection is refused as a port so you cannot lock yourself out.
* Nothing changes on the network until you press **Apply changes**. The saved config is re-applied at every boot.
* Not included: 802.1X, RSTP/MSTP, HTTPS, BRIDGE-MIB, PoE. Software switching is fine for a lab, not wire-speed.
* Port security is an allow-list (no MAC learning limit). Storm control is packets/second. Ports in a port-channel use the channel's VLAN settings.
* Images and installers are built by GitHub Actions and have not been boot-tested by the author - report failures with the log.

## Build it yourself (no commands)
1. Create a GitHub repo, upload all files keeping the folders (`app`, `build`, `launcher`, `.github/workflows/build.yml`).
   (Phone browser can't upload hidden `.github` folders: use *Add file -> Create new file*, type `.github/workflows/build.yml` as the name and paste the file.)
2. **Actions** tab -> *Build OT Virtual Switch images* -> **Run workflow**. ~15-20 min.
3. Download the files from **Releases** (or the run's Artifacts).

## Try without installing anything
`python3 app/server.py` on any computer starts the GUI in simulation mode at http://localhost:8080 (nothing is changed).
